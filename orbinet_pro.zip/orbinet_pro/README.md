# Web Enterprise Compatibility for Orbinet ERP

Technical name: `web_enterprise`

Provides the platform Community-safe Web Enterprise hooks: enterprise bootstrap, home menu, navbar, dark-mode bundles, branding helpers, and stable @web_enterprise/* paths.

This is not the standard edition code.


Merged from orbinet_enterprise: hides upgrade-only Settings entries and adds safe Ultra Demark powered-by link debranding without altering app/module records.


## Chatter layout controls

- Toggle chatter between side and bottom directly from the chatter toolbar.
- Resize side chatter with a draggable splitter; double-click resets to 60/40.
- Layout and split ratio are stored per browser.
- Orbinet Appearance is no longer exposed as a standalone top-level Settings menu; configuration remains available inside General Settings.

## Chatter cleaner

Activities are hidden by default and can be restored with the eye button in the chatter toolbar. The preference is stored per browser. Cleaner styles remain scoped to chatter and preserve messages, notes, attachments, followers, and search.

## Save and Discard controls

Editable backend forms now display explicit **Save** and **Discard** buttons in the form status area and form/dialog footers. The controls retain the standard `S` and `J` keyboard shortcuts and invoke the native form save/discard handlers. They are responsive, dark-mode compatible, and use the Web Enterprise visual system.

## AI workspace
Web Enterprise provides a provider-neutral assistant shell, role/company-aware profiles,
prompt templates, keyboard access, and stable frontend registries. Actual AI provider
connectors remain separate modules so organisations can select, replace, secure, or
disable them independently.

## Extension manager
The extension catalogue controls framework capabilities, records their source module
and provider key, and performs administrator-triggered health diagnostics. Disabling an
extension affects its framework contribution only; it does not bypass or rewrite the
source application's security model.
