/** @odoo-module **/
export const isEnterpriseCompatibilityLayer = true;
export const enterpriseEdition = 'community-compatible';
