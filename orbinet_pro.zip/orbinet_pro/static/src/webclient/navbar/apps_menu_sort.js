/** @odoo-module **/

/*
 * Orbinet App Launcher A-Z Sorting
 *
 * Odoo normally keeps app menu entries in menu sequence / installation order.
 * The Orbinet navbar should be easier to scan, so every app launcher source is
 * normalised to A-Z and the visible dropdown is also sorted as a safety net for
 * Odoo versions that build the app switcher directly from DOM/menu sections.
 */

import { registry } from "@web/core/registry";

function appTitle(app) {
    return (app?.label || app?.name || app?.display_name || "").toString().trim();
}

function sortApps(apps) {
    if (!Array.isArray(apps)) {
        return apps;
    }
    return [...apps].sort((a, b) =>
        appTitle(a).localeCompare(appTitle(b), undefined, {
            sensitivity: "base",
            numeric: true,
        })
    );
}

function sortRootTreeApps(tree) {
    if (tree && Array.isArray(tree.childrenTree)) {
        tree.childrenTree = sortApps(tree.childrenTree);
    }
    if (tree && Array.isArray(tree.children)) {
        tree.children = sortApps(tree.children);
    }
    return tree;
}

function patchMenuService() {
    const services = registry.category("services");
    let menuService;
    try {
        menuService = services.get("menu");
    } catch {
        return;
    }
    if (!menuService || menuService.__orbinetAppsSorted) {
        return;
    }

    const originalStart = menuService.start;
    menuService.start = function (...args) {
        const service = originalStart.apply(this, args);

        if (service?.getApps && !service.getApps.__orbinetAppsSorted) {
            const originalGetApps = service.getApps.bind(service);
            service.getApps = function (...getAppsArgs) {
                return sortApps(originalGetApps(...getAppsArgs));
            };
            service.getApps.__orbinetAppsSorted = true;
        }

        if (service?.getMenuAsTree && !service.getMenuAsTree.__orbinetAppsSorted) {
            const originalGetMenuAsTree = service.getMenuAsTree.bind(service);
            service.getMenuAsTree = function (...treeArgs) {
                const tree = originalGetMenuAsTree(...treeArgs);
                if (treeArgs[0] === "root" || tree?.id === "root") {
                    return sortRootTreeApps(tree);
                }
                return tree;
            };
            service.getMenuAsTree.__orbinetAppsSorted = true;
        }

        return service;
    };
    menuService.__orbinetAppsSorted = true;
}

function cleanText(text) {
    return (text || "").replace(/\s+/g, " ").trim();
}

function visibleLabel(el) {
    const clone = el.cloneNode(true);
    for (const node of clone.querySelectorAll(".badge, .o_badge, .o_counter, .dropdown-toggle, svg, img")) {
        node.remove();
    }
    return cleanText(clone.textContent);
}

function sortVisibleLauncherDropdown(menu) {
    if (!menu || menu.dataset.orbinetAppsSortedBusy === "1") {
        return;
    }

    const openToggle = document.querySelector(".o_main_navbar .o_menu_toggle[aria-expanded='true'], .o_main_navbar .o_menu_toggle.show");
    if (!openToggle) {
        return;
    }

    const items = Array.from(menu.children).filter((el) => {
        const label = visibleLabel(el);
        return label && !el.matches(".dropdown-divider, hr, script, style");
    });

    // Avoid touching normal section menus such as Website/Site. The app switcher
    // is a long list of app entries and is opened from the grid/menu toggle.
    if (items.length < 4) {
        return;
    }

    menu.dataset.orbinetAppsSortedBusy = "1";
    try {
        for (const item of [...items].sort((a, b) =>
            visibleLabel(a).localeCompare(visibleLabel(b), undefined, {
                sensitivity: "base",
                numeric: true,
            })
        )) {
            menu.appendChild(item);
        }
        menu.dataset.orbinetAppsSorted = "1";
    } finally {
        menu.dataset.orbinetAppsSortedBusy = "0";
    }
}

function applyVisibleDropdownSort() {
    const dropdowns = document.querySelectorAll(
        ".o_main_navbar .dropdown-menu.show, .o_main_navbar .o-dropdown--menu.show, .o_main_navbar .o-dropdown--menu"
    );
    for (const dropdown of dropdowns) {
        sortVisibleLauncherDropdown(dropdown);
    }
}

patchMenuService();

const observer = new MutationObserver(() => window.requestAnimationFrame(applyVisibleDropdownSort));

function start() {
    applyVisibleDropdownSort();
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "aria-expanded"] });
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
} else {
    start();
}
