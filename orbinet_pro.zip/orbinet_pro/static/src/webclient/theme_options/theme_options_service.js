import { registry } from "@web/core/registry";
import { user } from "@web/core/user";

const serviceRegistry = registry.category("services");

const PRESETS = {
    royal_purple: {
        home: "linear-gradient(135deg, #55006B 0%, #650078 52%, #4A005F 100%)",
        top: "#55006B",
        text: "#FFFFFF",
        hover: "#6D0085",
        border: "#55006B",
        iconStart: "#04965D",
        iconEnd: "#03445D",
    },
    emerald: {
        home: "linear-gradient(135deg, #064E3B 0%, #047857 55%, #022C22 100%)",
        top: "#064E3B",
        text: "#FFFFFF",
        hover: "#047857",
        border: "#022C22",
        iconStart: "#10B981",
        iconEnd: "#065F46",
    },
    ocean: {
        home: "linear-gradient(135deg, #083344 0%, #0369A1 55%, #0F172A 100%)",
        top: "#083344",
        text: "#FFFFFF",
        hover: "#0369A1",
        border: "#0F172A",
        iconStart: "#06B6D4",
        iconEnd: "#1E3A8A",
    },
    sunset: {
        home: "linear-gradient(135deg, #7C2D12 0%, #C2410C 48%, #4C0519 100%)",
        top: "#7C2D12",
        text: "#FFFFFF",
        hover: "#C2410C",
        border: "#4C0519",
        iconStart: "#F97316",
        iconEnd: "#BE123C",
    },
    slate: {
        home: "linear-gradient(135deg, #0F172A 0%, #334155 55%, #020617 100%)",
        top: "#0F172A",
        text: "#FFFFFF",
        hover: "#334155",
        border: "#020617",
        iconStart: "#64748B",
        iconEnd: "#1E293B",
    },
};

function cleanColor(value, fallback) {
    if (typeof value !== "string") {
        return fallback;
    }
    const color = value.trim();
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(color)) {
        return color;
    }
    if (/^(rgb|rgba|hsl|hsla)\(/i.test(color)) {
        return color;
    }
    return fallback;
}

function cleanBackground(value, fallback) {
    if (typeof value !== "string") {
        return fallback;
    }
    const background = value.trim();
    if (/^linear-gradient\(/i.test(background) || /^radial-gradient\(/i.test(background)) {
        return background;
    }
    return cleanColor(background, fallback);
}

function normalizedText(el) {
    return (el.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function hideOdooUserMenuLinks() {
    // Automatic on install: hide only the two Odoo-specific user menu entries.
    // Keep Shortcuts, Online, My Preferences/Profile, Log out, and custom items intact.
    const candidates = document.querySelectorAll(
        ".o_user_menu *, .o_user_menu_mobile *, .o_menu_systray .dropdown-menu *, .o-dropdown--menu *"
    );
    candidates.forEach((el) => {
        if (!(el instanceof HTMLElement)) {
            return;
        }
        const text = normalizedText(el);
        const href = (el.getAttribute("href") || "").toLowerCase();
        const title = (el.getAttribute("title") || "").toLowerCase();
        const isHelp = text === "help" || text === "odoo help" || title === "help";
        const isOdooAccount =
            text === "my odoo.com account" ||
            text === "my odoo account" ||
            text === "odoo account" ||
            href.includes("odoo.com/account") ||
            href.includes("accounts.odoo.com");
        if (isHelp || isOdooAccount) {
            const row =
                el.closest(".dropdown-item, .o-dropdown-item, .o-dropdown--item, li, a, button") || el;
            row.classList.add("d-none", "orbinet-hidden-odoo-link");
            row.setAttribute("aria-hidden", "true");
            row.style.setProperty("display", "none", "important");
        }
    });
}

function ensureFullscreenToggle() {
    const systray = document.querySelector(".o_main_navbar .o_menu_systray");
    if (!systray || systray.querySelector(".orbinet_fullscreen_toggle")) {
        return;
    }
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn border-0 px-2 orbinet_fullscreen_toggle";
    btn.title = "Toggle fullscreen";
    btn.setAttribute("aria-label", "Toggle fullscreen");
    btn.innerHTML = '<i class="fa fa-expand" aria-hidden="true"></i>';
    btn.addEventListener("click", async (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        try {
            if (!document.fullscreenElement) {
                await document.documentElement.requestFullscreen();
                btn.innerHTML = '<i class="fa fa-compress" aria-hidden="true"></i>';
            } else {
                await document.exitFullscreen();
                btn.innerHTML = '<i class="fa fa-expand" aria-hidden="true"></i>';
            }
        } catch (error) {
            console.warn("Orbinet fullscreen toggle failed", error);
        }
    });
    document.addEventListener("fullscreenchange", () => {
        btn.innerHTML = document.fullscreenElement
            ? '<i class="fa fa-compress" aria-hidden="true"></i>'
            : '<i class="fa fa-expand" aria-hidden="true"></i>';
    });
    systray.prepend(btn);
}



function applyBrandCleanup() {
    // General backend branding cleanup outside the user menu.
    document.querySelectorAll(".o_brand_promotion, .o_sub_menu_footer, .o_enterprise_label").forEach((el) => {
        el.classList.add("d-none");
    });
    hideOdooUserMenuLinks();
}

function childLabel(el) {
    const clone = el.cloneNode(true);
    clone.querySelectorAll(".badge, .o_badge, .fa, i, svg").forEach((n) => n.remove());
    return (clone.textContent || "").replace(/\s+/g, " ").trim();
}

function sortChildrenByText(container, selector, options = {}) {
    if (!container || container.dataset.orbinetSorting === "1") {
        return;
    }
    let children = [...container.children].filter((el) => !selector || el.matches(selector));
    children = children.filter((el) => childLabel(el));
    if (children.length < 2) {
        return;
    }
    const pinned = [];
    const normal = [];
    for (const el of children) {
        const label = childLabel(el).toLowerCase();
        if (options.pinAll && label === "all") {
            pinned.push(el);
        } else {
            normal.push(el);
        }
    }
    const sortedNormal = [...normal].sort((a, b) =>
        childLabel(a).localeCompare(childLabel(b), undefined, {
            sensitivity: "base",
            numeric: true,
        })
    );
    const sorted = [...pinned, ...sortedNormal];
    const changed = sorted.some((el, idx) => el !== children[idx]);
    if (!changed) {
        return;
    }
    container.dataset.orbinetSorting = "1";
    sorted.forEach((el) => container.appendChild(el));
    delete container.dataset.orbinetSorting;
}

function sortBackendSidebars() {
    // Settings sidebar blocks, e.g. General Settings, Inventory, Invoicing, Fleet.
    document.querySelectorAll(
        ".settings_tab, .o_setting_container .settings_tab, .o_settings_container .settings_tab, " +
        ".o_base_settings .settings_tab, .o_base_settings .settings, .o_setting_search"
    ).forEach((container) => {
        sortChildrenByText(container, ":scope > .tab, :scope > a, :scope > div, :scope > button");
    });

    // Extra robust pass for the left settings/app sidebars used by Odoo 18/19 variants.
    document.querySelectorAll(
        "aside .list-group, aside nav, .o_form_view .o_setting_container > .settings_tab, " +
        ".o_control_panel .o_cp_sidebar, .o_app_settings_sidebar, .o_apps_sidebar, " +
        ".o_web_settings_dashboard .list-group, .o_menu_sections .dropdown-menu"
    ).forEach((container) => {
        sortChildrenByText(container, ":scope > a, :scope > button, :scope > div, :scope > li");
    });

    // Apps page categories: keep All first, sort the remaining categories alphabetically.
    document.querySelectorAll(
        ".o_search_panel_section .list-group, .o_search_panel_category .list-group, " +
        ".o_search_panel .list-group, .o_apps .o_search_panel .list-group, " +
        ".o_kanban_renderer .o_search_panel .list-group"
    ).forEach((container) => {
        sortChildrenByText(container, ":scope > a, :scope > button, :scope > div, :scope > li", { pinAll: true });
    });
}

export const orbinetThemeOptionsService = {
    start() {
        const settings = user.settings || {};
        const selected = settings.obs_theme_preset || "royal_purple";
        const preset = selected === "custom" ? PRESETS.royal_purple : (PRESETS[selected] || PRESETS.royal_purple);
        const root = document.documentElement;
        const topBg = selected === "custom" ? cleanColor(settings.obs_topnav_bg_color, preset.top) : preset.top;
        const topText = selected === "custom" ? cleanColor(settings.obs_topnav_text_color, preset.text) : preset.text;
        const topHover = selected === "custom" ? cleanColor(settings.obs_topnav_hover_color, preset.hover) : preset.hover;
        const topBorder = selected === "custom" ? cleanColor(settings.obs_topnav_border_color, preset.border) : preset.border;
        const homeBg = selected === "custom" ? cleanBackground(settings.obs_home_bg_gradient || settings.obs_home_bg_color, preset.home) : preset.home;
        const iconStart = selected === "custom" ? cleanColor(settings.obs_icon_gradient_start, preset.iconStart) : preset.iconStart;
        const iconEnd = selected === "custom" ? cleanColor(settings.obs_icon_gradient_end, preset.iconEnd) : preset.iconEnd;

        root.style.setProperty("--obs-topnav-bg", topBg);
        root.style.setProperty("--obs-topnav-color", topText);
        root.style.setProperty("--obs-topnav-hover-bg", topHover);
        root.style.setProperty("--obs-topnav-border", topBorder);
        root.style.setProperty("--obs-home-bg", homeBg);
        root.style.setProperty("--obs-icon-bg", `linear-gradient(135deg, ${iconStart} 0%, ${iconEnd} 100%)`);
        root.style.setProperty("--homeMenu-bg-image", "none");
        root.style.setProperty("--homeMenuCaption-color", topText);

        document.body.classList.add("obs_brand_clean", "obs_theme_ready");
        applyBrandCleanup();
        ensureFullscreenToggle();
        sortBackendSidebars();
        const observer = new MutationObserver(() => {
                applyBrandCleanup();
            ensureFullscreenToggle();
            sortBackendSidebars();
        });
        observer.observe(document.body, { childList: true, subtree: true });
        return { stop: () => observer.disconnect() };
    },
};

serviceRegistry.add("orbinet_theme_options", orbinetThemeOptionsService);
