/** @odoo-module **/

// Kept as a compatibility stub. Website debranding is implemented by
// frontend_debranding.js so public pages do not run overlapping observers.
