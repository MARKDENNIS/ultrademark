/** @odoo-module **/

import { registry } from "@web/core/registry";
import { rpc } from "@web/core/network/rpc";
import { _t } from "@web/core/l10n/translation";

export const enterpriseAIProviderRegistry = registry.category("web_enterprise.ai_providers");
export const enterpriseAIPromptContributionRegistry = registry.category("web_enterprise.ai_prompts");

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

const aiWorkspaceService = {
    dependencies: ["enterprise_experience", "notification"],
    async start(env, { enterprise_experience: experience, notification }) {
        let payload = { enabled: false, profiles: [], enabled_extensions: [] };
        try {
            payload = await rpc("/web_enterprise/ai/workspace", {});
        } catch {
            payload = { enabled: false, profiles: [], enabled_extensions: [] };
        }
        if (!payload.enabled || experience.config?.ai_workspace === false) {
            return { open: () => {}, providers: enterpriseAIProviderRegistry };
        }

        let root = null;
        let selectedProfile = payload.profiles[0] || null;
        let selectedPrompt = selectedProfile?.prompts?.[0] || null;

        const close = () => {
            root?.remove();
            root = null;
        };

        const providerFor = (profile) => {
            return enterpriseAIProviderRegistry.getAll().find((provider) =>
                provider?.key === profile?.provider_key || provider?.provider_key === profile?.provider_key
            );
        };

        const composedPrompt = () => {
            if (!selectedProfile) return "";
            const instruction = root?.querySelector(".o_enterprise_ai_instruction")?.value?.trim() || "";
            const parts = [selectedProfile.system_prompt, selectedPrompt?.template, instruction].filter(Boolean);
            return parts.join("\n\n");
        };

        const renderPrompts = () => {
            const list = root?.querySelector(".o_enterprise_ai_prompts");
            if (!list) return;
            list.replaceChildren();
            const contributed = enterpriseAIPromptContributionRegistry.getAll()
                .filter((item) => !item.profile_key || item.profile_key === selectedProfile?.provider_key);
            const prompts = [...(selectedProfile?.prompts || []), ...contributed];
            if (!prompts.length) {
                const empty = document.createElement("div");
                empty.className = "o_enterprise_ai_empty";
                empty.textContent = _t("No prompt templates are available for this profile.");
                list.appendChild(empty);
                return;
            }
            prompts.forEach((prompt, index) => {
                const button = document.createElement("button");
                button.type = "button";
                button.className = `o_enterprise_ai_prompt${selectedPrompt === prompt ? " is-active" : ""}`;
                button.innerHTML = `<i class="fa ${escapeHtml(prompt.icon || "fa-commenting-o")}"></i><span><strong>${escapeHtml(prompt.name || _t("Prompt"))}</strong><small>${escapeHtml(prompt.action_mode || _t("Assist"))}</small></span>`;
                button.addEventListener("click", () => {
                    selectedPrompt = prompt;
                    renderPrompts();
                });
                if (!selectedPrompt && index === 0) selectedPrompt = prompt;
                list.appendChild(button);
            });
        };

        const renderProfiles = () => {
            const selector = root?.querySelector(".o_enterprise_ai_profile_select");
            if (!selector) return;
            selector.replaceChildren();
            payload.profiles.forEach((profile) => {
                const option = document.createElement("option");
                option.value = String(profile.id);
                option.textContent = profile.name;
                option.selected = profile.id === selectedProfile?.id;
                selector.appendChild(option);
            });
            selector.addEventListener("change", () => {
                selectedProfile = payload.profiles.find((profile) => String(profile.id) === selector.value) || null;
                selectedPrompt = selectedProfile?.prompts?.[0] || null;
                root.querySelector(".o_enterprise_ai_profile_description").textContent = selectedProfile?.description || "";
                renderPrompts();
            });
        };

        const execute = async () => {
            const prompt = composedPrompt();
            if (!prompt) {
                notification.add(_t("Select a profile and provide an instruction."), { type: "warning" });
                return;
            }
            const provider = providerFor(selectedProfile);
            const result = root.querySelector(".o_enterprise_ai_result");
            result.value = "";
            if (provider?.execute) {
                root.classList.add("is-busy");
                try {
                    const response = await provider.execute({
                        env,
                        profile: selectedProfile,
                        prompt: selectedPrompt,
                        instruction: root.querySelector(".o_enterprise_ai_instruction").value,
                        composedPrompt: prompt,
                    });
                    result.value = typeof response === "string" ? response : JSON.stringify(response, null, 2);
                } catch (error) {
                    result.value = error?.message || _t("The provider adapter could not complete the request.");
                } finally {
                    root.classList.remove("is-busy");
                }
            } else {
                result.value = prompt;
                notification.add(_t("No provider connector is registered. The prepared prompt is ready to copy."), { type: "info" });
            }
        };

        const open = () => {
            close();
            selectedProfile = payload.profiles[0] || null;
            selectedPrompt = selectedProfile?.prompts?.[0] || null;
            root = document.createElement("div");
            root.className = "o_enterprise_ai_workspace";
            root.innerHTML = `
                <div class="o_enterprise_ai_backdrop"></div>
                <aside class="o_enterprise_ai_panel" role="dialog" aria-modal="true" aria-label="${escapeHtml(_t("AI Workspace"))}">
                    <header>
                        <div><strong>${escapeHtml(_t("AI Workspace"))}</strong><span>${escapeHtml(_t("Provider-neutral assistance across the complete system"))}</span></div>
                        <button type="button" class="o_enterprise_ai_close" aria-label="${escapeHtml(_t("Close"))}"><i class="fa fa-times"></i></button>
                    </header>
                    <section class="o_enterprise_ai_profile">
                        <label>${escapeHtml(_t("Assistant profile"))}</label>
                        <select class="o_enterprise_ai_profile_select form-select"></select>
                        <small class="o_enterprise_ai_profile_description">${escapeHtml(selectedProfile?.description || "")}</small>
                    </section>
                    <div class="o_enterprise_ai_body">
                        <nav class="o_enterprise_ai_prompts"></nav>
                        <main>
                            <label>${escapeHtml(_t("Your instruction"))}</label>
                            <textarea class="o_enterprise_ai_instruction form-control" rows="6" placeholder="${escapeHtml(_t("Describe the task, question or output you need…"))}"></textarea>
                            <div class="o_enterprise_ai_actions">
                                <button type="button" class="btn btn-primary o_enterprise_ai_run"><i class="fa fa-magic"></i> ${escapeHtml(_t("Run / Prepare"))}</button>
                                <button type="button" class="btn btn-secondary o_enterprise_ai_copy"><i class="fa fa-copy"></i> ${escapeHtml(_t("Copy Result"))}</button>
                            </div>
                            <label>${escapeHtml(_t("Result"))}</label>
                            <textarea class="o_enterprise_ai_result form-control" rows="10" readonly="readonly"></textarea>
                            <p class="o_enterprise_ai_notice">${escapeHtml(_t("Write actions require explicit confirmation and remain the responsibility of the installed provider connector."))}</p>
                        </main>
                    </div>
                    <footer><span>${escapeHtml(_t("Ctrl+Shift+Space"))}</span><span>${escapeHtml(_t("Provider connectors are managed as extensions"))}</span></footer>
                </aside>`;
            document.body.appendChild(root);
            renderProfiles();
            renderPrompts();
            root.querySelector(".o_enterprise_ai_backdrop").addEventListener("click", close);
            root.querySelector(".o_enterprise_ai_close").addEventListener("click", close);
            root.querySelector(".o_enterprise_ai_run").addEventListener("click", execute);
            root.querySelector(".o_enterprise_ai_copy").addEventListener("click", async () => {
                const text = root.querySelector(".o_enterprise_ai_result").value || composedPrompt();
                if (!text) return;
                await navigator.clipboard.writeText(text);
                notification.add(_t("Copied to clipboard."), { type: "success" });
            });
            root.addEventListener("keydown", (event) => { if (event.key === "Escape") close(); });
            root.querySelector(".o_enterprise_ai_instruction").focus();
        };

        const addNavbarButton = () => {
            if (document.querySelector(".o_enterprise_ai_nav_button")) return;
            const navbar = document.querySelector(".o_main_navbar");
            if (!navbar) return;
            const button = document.createElement("button");
            button.type = "button";
            button.className = "o_enterprise_ai_nav_button btn btn-link";
            button.title = _t("AI Workspace");
            button.setAttribute("aria-label", _t("AI Workspace"));
            button.innerHTML = '<i class="fa fa-magic"></i>';
            button.addEventListener("click", open);
            navbar.appendChild(button);
        };
        addNavbarButton();
        new MutationObserver(addNavbarButton).observe(document.body, { childList: true, subtree: true });

        if (payload.shortcut && experience.config?.keyboard_shortcuts !== false) {
            window.addEventListener("keydown", (event) => {
                if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.code === "Space") {
                    event.preventDefault();
                    open();
                }
            });
        }
        return { open, close, providers: enterpriseAIProviderRegistry, promptRegistry: enterpriseAIPromptContributionRegistry };
    },
};

registry.category("services").add("enterprise_ai_workspace", aiWorkspaceService);
