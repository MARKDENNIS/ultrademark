/** @odoo-module **/

import { registry } from "@web/core/registry";
import { rpc } from "@web/core/network/rpc";
import { _t } from "@web/core/l10n/translation";

export const enterpriseCommandRegistry = registry.category("web_enterprise.commands");
export const enterpriseWorkspaceRegistry = registry.category("web_enterprise.workspace_items");
export const enterpriseSearchProviderRegistry = registry.category("web_enterprise.search_providers");
export const enterpriseNotificationProviderRegistry = registry.category("web_enterprise.notification_providers");
export const enterpriseContextActionRegistry = registry.category("web_enterprise.context_actions");

const RECENTS_KEY = "web_enterprise.command_recents";

function flattenMenus(node, target = []) {
    for (const child of node?.childrenTree || node?.children || []) {
        if (child.action || child.id) {
            target.push({
                id: child.id,
                name: child.name || child.label || _t("Untitled"),
                action: child.action,
                appID: child.appID,
                source: "menu",
                menu: child,
            });
        }
        flattenMenus(child, target);
    }
    return target;
}

function readRecents() {
    try {
        const data = JSON.parse(localStorage.getItem(RECENTS_KEY) || "[]");
        return Array.isArray(data) ? data : [];
    } catch {
        return [];
    }
}

function saveRecent(command) {
    const clean = { id: command.id, name: command.name, source: command.source };
    const rows = [clean, ...readRecents().filter((row) => `${row.source}:${row.id}` !== `${clean.source}:${clean.id}`)].slice(0, 8);
    localStorage.setItem(RECENTS_KEY, JSON.stringify(rows));
}

function makePalette(runCommand, getCommands, showRecents) {
    document.querySelector(".o_enterprise_command_palette")?.remove();
    const root = document.createElement("div");
    root.className = "o_enterprise_command_palette";
    root.innerHTML = `
        <div class="o_enterprise_command_backdrop"></div>
        <section class="o_enterprise_command_panel" role="dialog" aria-modal="true" aria-label="${_t("Command palette")}">
            <header><i class="fa fa-search"/><input type="search" autocomplete="off" placeholder="${_t("Search applications, menus and commands…")}"/><kbd>Esc</kbd></header>
            <div class="o_enterprise_command_results"></div>
            <footer><span>${_t("Navigate with arrow keys")}</span><span>${_t("Enter to open")}</span></footer>
        </section>`;
    document.body.appendChild(root);
    const input = root.querySelector("input");
    const results = root.querySelector(".o_enterprise_command_results");
    let filtered = [];
    let active = 0;

    const close = () => root.remove();
    const render = () => {
        const query = input.value.trim().toLowerCase();
        const all = getCommands();
        filtered = all.filter((item) => !query || item.name.toLowerCase().includes(query)).slice(0, 40);
        if (!query && showRecents) {
            const keys = new Set(readRecents().map((r) => `${r.source}:${r.id}`));
            filtered.sort((a, b) => Number(keys.has(`${b.source}:${b.id}`)) - Number(keys.has(`${a.source}:${a.id}`)));
        }
        active = Math.min(active, Math.max(0, filtered.length - 1));
        results.replaceChildren();
        if (!filtered.length) {
            const empty = document.createElement("div");
            empty.className = "o_enterprise_command_empty";
            empty.textContent = _t("No matching command");
            results.appendChild(empty);
            return;
        }
        filtered.forEach((item, index) => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = `o_enterprise_command_item${index === active ? " is-active" : ""}`;
            button.innerHTML = `<i class="fa ${item.icon || (item.source === "menu" ? "fa-folder-open-o" : "fa-bolt")}"/><span>${item.name}</span><small>${item.category || (item.source === "menu" ? _t("Menu") : _t("Command"))}</small>`;
            button.addEventListener("mouseenter", () => { active = index; render(); });
            button.addEventListener("click", () => { close(); runCommand(item); });
            results.appendChild(button);
        });
    };
    input.addEventListener("input", render);
    root.querySelector(".o_enterprise_command_backdrop").addEventListener("click", close);
    root.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape") close();
        if (ev.key === "ArrowDown") { ev.preventDefault(); active = Math.min(active + 1, filtered.length - 1); render(); }
        if (ev.key === "ArrowUp") { ev.preventDefault(); active = Math.max(active - 1, 0); render(); }
        if (ev.key === "Enter" && filtered[active]) { ev.preventDefault(); const item = filtered[active]; close(); runCommand(item); }
    });
    render();
    input.focus();
}

const experienceService = {
    dependencies: ["action", "menu"],
    async start(env, { action, menu }) {
        let config = {};
        try {
            config = await rpc("/web_enterprise/experience/config", {});
        } catch {
            config = { command_palette: true, focus_mode: true, recent_commands: true, density: "comfortable" };
        }
        document.body.classList.toggle("o_enterprise_density_compact", config.density === "compact");
        document.body.classList.toggle("o_enterprise_density_comfortable", config.density !== "compact");

        const customCommands = () => enterpriseCommandRegistry.getAll().map((entry, index) => ({
            id: entry.id || entry.name || index,
            name: entry.name || _t("Command"),
            category: entry.category,
            icon: entry.icon,
            source: "extension",
            run: entry.run,
            action: entry.action,
        }));
        const menuCommands = () => {
            try { return flattenMenus(menu.getMenuAsTree("root")); } catch { return []; }
        };
        const commands = () => [...customCommands(), ...menuCommands()];
        const run = async (command) => {
            if (config.recent_commands) saveRecent(command);
            if (typeof command.run === "function") return command.run(env);
            if (command.source === "menu" && typeof menu.selectMenu === "function") return menu.selectMenu(command.menu);
            if (command.action) return action.doAction(command.action);
        };
        const open = () => makePalette(run, commands, config.recent_commands);

        const focusToggle = () => {
            if (!config.focus_mode) return;
            document.body.classList.toggle("o_enterprise_focus_mode");
        };
        if (config.command_palette || config.keyboard_shortcuts) {
            window.addEventListener("keydown", (ev) => {
                const target = ev.target;
                const editing = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target?.isContentEditable;
                if (config.command_palette && (ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "k") {
                    ev.preventDefault(); open();
                }
                if (config.focus_mode && !editing && ev.altKey && ev.key.toLowerCase() === "f") {
                    ev.preventDefault(); focusToggle();
                }
            });
        }
        return {
            config,
            openCommandPalette: open,
            toggleFocusMode: focusToggle,
            commandRegistry: enterpriseCommandRegistry,
            workspaceRegistry: enterpriseWorkspaceRegistry,
            searchProviderRegistry: enterpriseSearchProviderRegistry,
            notificationProviderRegistry: enterpriseNotificationProviderRegistry,
            contextActionRegistry: enterpriseContextActionRegistry,
        };
    },
};
registry.category("services").add("enterprise_experience", experienceService);
