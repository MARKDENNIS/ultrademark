/** @odoo-module **/

/*
 * Orbinet logo and icon debranding for Odoo 19.
 * Uses the uploaded Orbinet logo and icon whenever the web client, login page,
 * or database pages render the default Odoo logo/favicon/title.
 */
(function () {
    "use strict";

    const BRAND_CONFIG = window.__webEnterpriseBrandConfig || {};

    if (window.__orbinetLogoIconDebrandingLoaded) {
        return;
    }
    window.__orbinetLogoIconDebrandingLoaded = true;

    const BRAND = String(BRAND_CONFIG.title || window.__webEnterpriseBrandTitle || "Orbinet ERP").trim() || "Orbinet ERP";
    const LOGO = BRAND_CONFIG.logoUrl || "/web/image/res.company/1/logo";
    const ICON = BRAND_CONFIG.iconUrl || LOGO;
    const ICON_32 = ICON;
    const APP_ICON = ICON;

    function looksLikeOdooAsset(value) {
        const src = String(value || "").toLowerCase();
        return src.includes("/web/static/img/logo") ||
            src.includes("/web/static/img/odoo") ||
            src.includes("odoo_logo") ||
            src.includes("odoo-icon") ||
            src.includes("favicon.ico") ||
            src.includes("/web/image/website/") && src.includes("logo");
    }

    function setTitle() {
        // Browser title is controlled centrally by title_guard.js so app names are preserved.
        if (window.__orbinetTitleGuardLoaded) {
            return;
        }
        if (!document.title || /odoo/i.test(document.title)) {
            document.title = BRAND;
        }
    }

    function upsertIconLink(rel, href, sizes) {
        let link = document.head && document.head.querySelector(`link[rel='${rel}'][data-orbinet-branding='1']`);
        if (!link && document.head) {
            link = document.createElement("link");
            link.setAttribute("rel", rel);
            link.setAttribute("data-orbinet-branding", "1");
            document.head.appendChild(link);
        }
        if (link) {
            link.setAttribute("href", href);
            link.setAttribute("type", "image/png");
            if (sizes) link.setAttribute("sizes", sizes);
        }
    }

    function replaceFaviconLinks() {
        if (!document.head) return;
        for (const link of document.head.querySelectorAll("link[rel~='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']")) {
            link.setAttribute("href", ICON);
            link.setAttribute("type", "image/png");
            link.setAttribute("data-orbinet-replaced", "1");
        }
        upsertIconLink("icon", ICON_32, "32x32");
        upsertIconLink("shortcut icon", ICON, "64x64");
        upsertIconLink("apple-touch-icon", APP_ICON, "128x128");
    }

    function replaceImage(img) {
        if (!img || img.dataset.orbinetLogoReplaced === "1") return;
        const src = img.getAttribute("src") || img.src || "";
        if (!looksLikeOdooAsset(src)) return;
        img.dataset.orbinetOriginalSrc = src;
        img.dataset.orbinetLogoReplaced = "1";
        img.setAttribute("src", LOGO);
        img.setAttribute("alt", BRAND);
        img.setAttribute("title", BRAND);
        img.style.objectFit = "contain";
    }

    function replaceLogos(root) {
        const scope = root && root.querySelectorAll ? root : document;
        for (const img of scope.querySelectorAll("img")) {
            replaceImage(img);
        }

        // Some screens render the Odoo logo as a background or empty logo container.
        for (const box of scope.querySelectorAll(".o_login_logo, .oe_login_logo, .o_database_logo, .oe_logo")) {
            box.style.backgroundImage = `url('${LOGO}')`;
            box.style.backgroundRepeat = "no-repeat";
            box.style.backgroundPosition = "center";
            box.style.backgroundSize = "contain";
            box.setAttribute("aria-label", BRAND);
            box.setAttribute("title", BRAND);
        }

        // Backend app/menu icon placeholders which may use Odoo favicon/icon.
        for (const img of scope.querySelectorAll(".o_app_icon img, .o_app img, .o_home_menu img")) {
            const src = img.getAttribute("src") || "";
            if (looksLikeOdooAsset(src)) {
                img.setAttribute("src", APP_ICON);
                img.setAttribute("alt", BRAND);
            }
        }
    }

    function applyBranding(root) {
        setTitle();
        replaceFaviconLinks();
        replaceLogos(root || document);
    }

    document.addEventListener("DOMContentLoaded", () => applyBranding(document));
    window.addEventListener("load", () => applyBranding(document));

    if (window.MutationObserver) {
        new MutationObserver((records) => {
            for (const record of records) {
                for (const node of record.addedNodes || []) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        applyBranding(node);
                    }
                }
            }
            setTitle();
            replaceFaviconLinks();
        }).observe(document.documentElement, { childList: true, subtree: true });
    }

    // Avoid permanent full-DOM polling: observers and lifecycle events are sufficient.
    applyBranding(document);
})();
