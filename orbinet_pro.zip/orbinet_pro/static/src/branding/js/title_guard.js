/** @odoo-module **/
(function () {
    "use strict";

    const BRAND_CONFIG = window.__webEnterpriseBrandConfig || {};
    if (window.__orbinetTitleGuardLoaded) return;
    window.__orbinetTitleGuardLoaded = true;

    const BRAND = String(BRAND_CONFIG.title || window.__webEnterpriseBrandTitle || "Orbinet ERP").trim() || "Orbinet ERP";
    const ICON_32 = BRAND_CONFIG.iconUrl || BRAND_CONFIG.logoUrl || "/web/image/res.company/1/logo";
    const ICON_64 = BRAND_CONFIG.iconUrl || ICON_32;
    const ICON_128 = BRAND_CONFIG.iconUrl || ICON_64;

    let writingTitle = false;
    let applyQueued = false;
    let iconsApplied = false;

    function clean(text) {
        return String(text || "")
            .replace(/\s+/g, " ")
            .replace(/\bOdoo\b/gi, "")
            .replace(/^[-|•:]+|[-|•:]+$/g, "")
            .trim();
    }

    function findAppName() {
        const candidates = [
            ".o_main_navbar .o_menu_brand",
            ".o_breadcrumb .breadcrumb-item:first-child",
            ".breadcrumb .breadcrumb-item:first-child",
            ".o_action_manager .o_control_panel .o_breadcrumb .active",
            ".o_control_panel .breadcrumb-item.active",
        ];
        for (const selector of candidates) {
            const node = document.querySelector(selector);
            const value = clean(node && node.textContent);
            if (value && value.toLowerCase() !== BRAND.toLowerCase()) return value;
        }
        return "";
    }

    function wantedTitle() {
        const app = findAppName();
        return app ? `${BRAND} | ${app}` : BRAND;
    }

    function forceTitle() {
        const wanted = wantedTitle();
        if (document.title !== wanted) {
            writingTitle = true;
            document.title = wanted;
            writingTitle = false;
        }
    }

    function upsertIcon(rel, href, sizes) {
        if (!document.head) return;
        let link = document.head.querySelector(`link[rel='${rel}'][data-orbinet-branding='1']`);
        if (!link) {
            link = document.createElement("link");
            link.rel = rel;
            link.type = "image/png";
            link.setAttribute("data-orbinet-branding", "1");
            document.head.appendChild(link);
        }
        if (link.getAttribute("href") !== href) link.href = href;
        if (sizes) link.sizes = sizes;
    }

    function forceIcons() {
        if (!document.head || iconsApplied) return;
        for (const link of document.head.querySelectorAll("link[rel~='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']")) {
            link.href = link.rel === "apple-touch-icon" ? ICON_128 : (link.rel === "icon" ? ICON_32 : ICON_64);
            link.type = "image/png";
            link.setAttribute("data-orbinet-replaced", "1");
        }
        upsertIcon("icon", ICON_32, "32x32");
        upsertIcon("shortcut icon", ICON_64, "64x64");
        upsertIcon("apple-touch-icon", ICON_128, "128x128");
        let meta = document.head.querySelector("meta[name='application-name']");
        if (!meta) {
            meta = document.createElement("meta");
            meta.name = "application-name";
            document.head.appendChild(meta);
        }
        meta.content = BRAND;
        iconsApplied = true;
    }

    const proto = Document.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "title");
    if (descriptor && descriptor.set && descriptor.get && !window.__orbinetDocumentTitlePatched) {
        window.__orbinetDocumentTitlePatched = true;
        Object.defineProperty(document, "title", {
            configurable: true,
            get() { return descriptor.get.call(document); },
            set(value) {
                if (writingTitle) return descriptor.set.call(document, value);
                const incoming = clean(value);
                if (!incoming || /odoo/i.test(incoming) || incoming === BRAND || incoming.includes("|") || incoming.includes("-") || incoming.includes("•")) {
                    return descriptor.set.call(document, wantedTitle());
                }
                return descriptor.set.call(document, `${BRAND} | ${incoming}`);
            },
        });
    }

    function apply() {
        applyQueued = false;
        try {
            forceTitle();
            forceIcons();
        } catch (_) {}
    }

    function scheduleApply() {
        if (applyQueued) return;
        applyQueued = true;
        requestAnimationFrame(apply);
    }

    apply();
    document.addEventListener("DOMContentLoaded", scheduleApply, { once: true });
    window.addEventListener("load", scheduleApply, { once: true });
    window.addEventListener("hashchange", scheduleApply);
    window.addEventListener("popstate", scheduleApply);

    if (window.MutationObserver && document.documentElement) {
        new MutationObserver((records) => {
            for (const record of records) {
                if (record.addedNodes.length || record.removedNodes.length) {
                    scheduleApply();
                    break;
                }
            }
        }).observe(document.documentElement, { childList: true, subtree: true });
    }
})();
