/** @odoo-module **/

(function () {
    "use strict";
    if (window.__orbinetPoweredByDebrandingLoaded) return;
    window.__orbinetPoweredByDebrandingLoaded = true;

    const COMPANY_URL = "https://www.ultrademark.com";
    const COMPANY_LABEL = "Ultra Demark Technologies Ltd.";

    function updateLinks(root) {
        const scope = root && root.querySelectorAll ? root : document;
        for (const link of scope.querySelectorAll("a[href*='odoo.com'], a[href*='odoo.com/']")) {
            const text = (link.textContent || "").trim().toLowerCase();
            const containerText = (link.closest("p, div, footer, small, span, li")?.textContent || "").toLowerCase();
            if (text.includes("odoo") || containerText.includes("powered by") || /odoo\.com/i.test(link.href || "")) {
                link.href = COMPANY_URL;
                link.target = "_blank";
                link.rel = "noopener noreferrer";
                if (!text || text.includes("odoo") || containerText.includes("powered by")) {
                    link.textContent = COMPANY_LABEL;
                }
            }
        }
    }


    function hideWebsiteSlogan(root) {
        const scope = root && root.querySelectorAll ? root : document;
        scope.querySelectorAll('a, span, small, p, div, footer').forEach((el) => {
            const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
            if (/^(the\s*)?#1\s*open\s*source\s*ecommerce$/i.test(text)) {
                el.style.setProperty('display', 'none', 'important');
                el.setAttribute('aria-hidden', 'true');
            }
        });
    }

    function apply(root) {
        try {
            updateLinks(root || document);
            hideWebsiteSlogan(root || document);
        } catch (e) {}
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => apply(document));
    } else {
        apply(document);
    }
    window.addEventListener("load", () => apply(document));

    if (window.MutationObserver) {
        new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes || []) {
                    if (node.nodeType === Node.ELEMENT_NODE) apply(node);
                }
            }
        }).observe(document.documentElement, { childList: true, subtree: true });
    }
})();
