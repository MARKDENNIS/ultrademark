/** @odoo-module **/

/*
 * Orbinet POS debranding for Odoo 19.
 * This is intentionally DOM-safe: it does not patch POS business logic. It only
 * replaces visible Odoo branding text, logos/icons, favicon, and the POS tab title.
 */
(function () {
    "use strict";

    const BRAND_CONFIG = window.__webEnterpriseBrandConfig || {};

    if (window.__orbinetPosDebrandingLoaded) {
        return;
    }
    window.__orbinetPosDebrandingLoaded = true;

    const BRAND = String(BRAND_CONFIG.title || "Orbinet ERP").replace(/\s+ERP$/i, "");
    const ERP_TITLE = String(BRAND_CONFIG.title || "Orbinet ERP");
    const POS_TITLE = `${BRAND} POS`;
    window.__orbinetInitialTitle = POS_TITLE;
    const LOGO = BRAND_CONFIG.logoUrl || "/web/image/res.company/1/logo";
    const ICON = BRAND_CONFIG.iconUrl || LOGO;
    const ICON_32 = ICON;
    const APP_ICON = ICON;

    function setPosTitle() {
        const current = String(document.title || "");
        if (!current || /odoo/i.test(current) || /point\s*of\s*sale/i.test(current) || current !== POS_TITLE) {
            document.title = POS_TITLE;
        }
    }

    function upsertIconLink(rel, href, sizes) {
        if (!document.head) return;
        let link = document.head.querySelector(`link[rel='${rel}'][data-orbinet-pos='1']`);
        if (!link) {
            link = document.createElement("link");
            link.setAttribute("rel", rel);
            link.setAttribute("data-orbinet-pos", "1");
            document.head.appendChild(link);
        }
        link.setAttribute("href", href);
        link.setAttribute("type", "image/png");
        if (sizes) link.setAttribute("sizes", sizes);
    }

    function replaceFavicon() {
        if (!document.head) return;
        for (const link of document.head.querySelectorAll("link[rel~='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']")) {
            link.setAttribute("href", ICON);
            link.setAttribute("type", "image/png");
            link.setAttribute("data-orbinet-pos-replaced", "1");
        }
        upsertIconLink("icon", ICON_32, "32x32");
        upsertIconLink("shortcut icon", ICON, "64x64");
        upsertIconLink("apple-touch-icon", APP_ICON, "128x128");
    }

    function looksLikeOdooAsset(value) {
        const src = String(value || "").toLowerCase();
        return src.includes("/web/static/img/logo") ||
            src.includes("/web/static/img/odoo") ||
            src.includes("odoo_logo") ||
            src.includes("odoo-icon") ||
            src.includes("favicon.ico") ||
            src.includes("/point_of_sale/static") && src.includes("odoo");
    }

    function replaceImages(root) {
        const scope = root && root.querySelectorAll ? root : document;
        for (const img of scope.querySelectorAll("img")) {
            const src = img.getAttribute("src") || img.src || "";
            const alt = img.getAttribute("alt") || "";
            const title = img.getAttribute("title") || "";
            if (looksLikeOdooAsset(src) || /odoo/i.test(alt) || /odoo/i.test(title)) {
                img.setAttribute("src", LOGO);
                img.setAttribute("alt", ERP_TITLE);
                img.setAttribute("title", ERP_TITLE);
                img.style.objectFit = "contain";
                img.dataset.orbinetPosReplaced = "1";
            }
        }

        for (const box of scope.querySelectorAll(".pos-logo, .o_pos_logo, .pos-branding, .o_pos_branding, .loader-logo, .o_loading_logo")) {
            box.style.backgroundImage = `url('${LOGO}')`;
            box.style.backgroundRepeat = "no-repeat";
            box.style.backgroundPosition = "center";
            box.style.backgroundSize = "contain";
            box.setAttribute("aria-label", ERP_TITLE);
            box.setAttribute("title", ERP_TITLE);
        }
    }

    function replaceTextNodes(root) {
        const scope = root && root.querySelectorAll ? root : document;
        const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                const text = node.nodeValue || "";
                if (!/odoo/i.test(text)) return NodeFilter.FILTER_REJECT;
                const parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                const tag = parent.tagName;
                if (["SCRIPT", "STYLE", "TEXTAREA", "INPUT", "CODE", "PRE"].includes(tag)) {
                    return NodeFilter.FILTER_REJECT;
                }
                return NodeFilter.FILTER_ACCEPT;
            },
        });
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        for (const node of nodes) {
            node.nodeValue = node.nodeValue
                .replace(/Odoo\s+POS/gi, "Orbinet POS")
                .replace(/Odoo\s+Point\s+of\s+Sale/gi, "Orbinet Point of Sale")
                .replace(/Powered\s+by\s+Odoo/gi, "Powered by Orbinet")
                .replace(/Odoo/gi, BRAND);
        }
    }

    function replaceAttributes(root) {
        const scope = root && root.querySelectorAll ? root : document;
        for (const el of scope.querySelectorAll("[title], [aria-label], [placeholder], [alt]")) {
            for (const attr of ["title", "aria-label", "placeholder", "alt"]) {
                const value = el.getAttribute(attr);
                if (value && /odoo/i.test(value)) {
                    el.setAttribute(attr, value.replace(/Odoo\s+POS/gi, "Orbinet POS").replace(/Odoo/gi, BRAND));
                }
            }
        }
    }

    function apply(root) {
        setPosTitle();
        replaceFavicon();
        replaceImages(root || document);
        replaceAttributes(root || document);
        replaceTextNodes(root || document);
    }

    document.addEventListener("DOMContentLoaded", () => apply(document));
    window.addEventListener("load", () => apply(document));

    if (window.MutationObserver) {
        new MutationObserver((records) => {
            for (const record of records) {
                for (const node of record.addedNodes || []) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        apply(node);
                    }
                }
            }
            setPosTitle();
            replaceFavicon();
        }).observe(document.documentElement, { childList: true, subtree: true });
    }

    setInterval(() => apply(document), 700);
    apply(document);
})();
