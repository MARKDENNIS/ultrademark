/** @odoo-module **/

import { registry } from "@web/core/registry";
const menuRegistry = registry.category("user_menuitems");
for (const itemName of ["documentation", "support", "odoo_account"]) {
    if (menuRegistry.contains(itemName)) {
        menuRegistry.remove(itemName);
    }
}
