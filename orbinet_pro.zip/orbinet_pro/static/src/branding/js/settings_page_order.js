/** @odoo-module **/

/*
 * Orbinet Settings order guard for Odoo 19.
 *
 * Required General Settings visual order:
 *   1) Every normal/app/custom settings section
 *   2) Developer Tools
 *   3) About
 *      - Orbinet Branding status is shown inside About
 *
 * This is done in the browser because Odoo/custom modules can inject Settings
 * blocks in different XML positions and some Odoo 19 builds do not expose
 * stable XML names for About or Developer Tools.
 */
(function () {
    "use strict";

    if (window.__orbinetSettingsOrderGuardLoaded) {
        return;
    }
    window.__orbinetSettingsOrderGuardLoaded = true;

    const DEV_NAME = "developer_tools";
    const ORBINET_NAME = "orbinet_branding_status";
    const ABOUT_NAME = "about";

    let busy = false;
    let timer = null;

    function clean(value) {
        return String(value || "").replace(/\s+/g, " ").trim();
    }

    function lc(value) {
        return clean(value).toLowerCase();
    }

    function key(el) {
        if (!el || el.nodeType !== Node.ELEMENT_NODE) return "";
        return lc(
            el.getAttribute("name") ||
            el.dataset.name ||
            el.dataset.key ||
            el.getAttribute("data-key") ||
            el.getAttribute("data-string") ||
            el.getAttribute("string") ||
            el.getAttribute("title") ||
            ""
        );
    }

    function titleText(el) {
        if (!el || el.nodeType !== Node.ELEMENT_NODE) return "";
        const heading = el.querySelector("h1,h2,h3,h4,.o_settings_section_title,.o_setting_box .o_setting_right_pane > label,.o_form_label");
        return lc((heading && heading.textContent) || el.getAttribute("string") || el.getAttribute("title") || el.textContent);
    }

    function sectionSelector() {
        return [
            ".app_settings_block",
            ".o_settings_container",
            ".o_settings_block",
            ".o_setting_block",
            "div[name]",
            "section[name]",
            "block[name]",
            "app[name]"
        ].join(",");
    }

    function isDeveloper(el) {
        const k = key(el);
        const t = titleText(el);
        return k === DEV_NAME || k === "developer tools" || t.startsWith("developer tools");
    }

    function isOrbinet(el) {
        const k = key(el);
        const t = titleText(el);
        return k === ORBINET_NAME || k === "orbinet branding" || t.startsWith("orbinet branding") || el.classList.contains("orbinet_branding_status_block");
    }

    function isAbout(el) {
        const k = key(el);
        const t = titleText(el);
        return k === ABOUT_NAME || k === "about" || t === "about" || t.startsWith("about ");
    }

    function isSection(el) {
        if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
        return el.matches(sectionSelector()) || isDeveloper(el) || isOrbinet(el) || isAbout(el);
    }

    function closestSection(el) {
        return el ? el.closest(sectionSelector()) : null;
    }

    function findByText(exactText) {
        const wanted = lc(exactText);
        return Array.from(document.querySelectorAll("h1,h2,h3,h4,span,div,label")).find((n) => lc(n.textContent) === wanted) || null;
    }

    function findSection(predicate) {
        return Array.from(document.querySelectorAll(sectionSelector())).find(predicate) || null;
    }

    function findDeveloper() {
        return document.querySelector('[name="developer_tools"], [data-key="developer_tools"], [data-name="developer_tools"]') ||
            findSection(isDeveloper) ||
            closestSection(findByText("Developer Tools"));
    }

    function findOrbinet() {
        return document.querySelector('[name="orbinet_branding_status"], [data-key="orbinet_branding_status"], [data-name="orbinet_branding_status"], .orbinet_branding_status_block') ||
            findSection(isOrbinet) ||
            closestSection(findByText("Orbinet Branding"));
    }

    function findAbout() {
        return document.querySelector('[name="about"], [data-key="about"], [data-name="about"]') ||
            findSection(isAbout) ||
            closestSection(findByText("About"));
    }

    function commonContainer(items) {
        const anchors = items.filter(Boolean);
        if (!anchors.length) return null;
        let p = anchors[0].parentElement;
        while (p && p !== document.body && p !== document.documentElement) {
            if (anchors.every((a) => p.contains(a))) return p;
            p = p.parentElement;
        }
        return anchors[0].parentElement;
    }

    function directChildFor(container, el) {
        if (!container || !el) return null;
        let cur = el;
        while (cur && cur.parentElement !== container) cur = cur.parentElement;
        return cur || el;
    }

    function moveOrbinetIntoAbout(orbinet, about) {
        if (!orbinet || !about || orbinet === about || about.contains(orbinet)) return;
        busy = true;
        try {
            // Keep the Orbinet setting inside the native About block, at its end.
            about.appendChild(orbinet);
        } finally {
            busy = false;
        }
    }

    function reorder() {
        if (busy) return;

        const devFound = findDeveloper();
        const aboutFound = findAbout();
        const orbinetFound = findOrbinet();

        // First put Orbinet Branding inside About when About exists.
        if (aboutFound && orbinetFound) {
            moveOrbinetIntoAbout(orbinetFound, aboutFound);
        }

        const devAfterMove = findDeveloper();
        const aboutAfterMove = findAbout();
        if (!devAfterMove && !aboutAfterMove) return;

        const container = commonContainer([devAfterMove, aboutAfterMove].filter(Boolean));
        if (!container) return;

        const dev = directChildFor(container, devAfterMove);
        const about = directChildFor(container, aboutAfterMove);
        const children = Array.from(container.children).filter((el) => el.nodeType === Node.ELEMENT_NODE);

        // Any section-like sibling which is not Developer Tools or About is an app/custom setting.
        const sectionChildren = children.filter((el) => isSection(el) || (devAfterMove && el.contains(devAfterMove)) || (aboutAfterMove && el.contains(aboutAfterMove)));
        const appSections = sectionChildren.filter((el) => el !== dev && el !== about && !isDeveloper(el) && !isAbout(el) && !isOrbinet(el));

        const desired = [];
        for (const el of appSections) if (el && !desired.includes(el)) desired.push(el);
        for (const el of [dev, about]) if (el && !desired.includes(el)) desired.push(el);

        if (desired.length < 2) return;
        const current = children.filter((el) => desired.includes(el));
        if (current.length === desired.length && desired.every((el, i) => current[i] === el)) return;

        busy = true;
        try {
            for (const el of desired) container.appendChild(el);
        } finally {
            busy = false;
        }
    }

    function schedule() {
        clearTimeout(timer);
        timer = setTimeout(reorder, 80);
    }

    function scrollSelected(item) {
        if (!item) return;
        const rawKey = item.dataset.key || item.dataset.name || item.getAttribute("data-menu") || item.getAttribute("href") || "";
        const k = rawKey.replace(/^#/, "");
        const label = clean(item.textContent || item.getAttribute("title") || "");
        let target = null;
        if (k && window.CSS && CSS.escape) {
            target = document.querySelector(`[name="${CSS.escape(k)}"], [data-key="${CSS.escape(k)}"], [data-name="${CSS.escape(k)}"]`);
        }
        if (!target && label) {
            target = findSection((el) => titleText(el).startsWith(label.toLowerCase()));
        }
        if (target && target.scrollIntoView) {
            setTimeout(() => target.scrollIntoView({ block: "start" }), 100);
        }
    }

    document.addEventListener("click", (ev) => {
        const item = ev.target.closest && ev.target.closest(".settings_tab, .o_app, .o_setting_search_result, [data-menu], [data-key], [data-name]");
        if (item) scrollSelected(item);
        schedule();
    }, true);

    document.addEventListener("DOMContentLoaded", schedule);
    window.addEventListener("load", schedule);
    window.addEventListener("hashchange", schedule);

    if (window.MutationObserver) {
        new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
    }

    // DOM observer and navigation events keep ordering current without polling.
    schedule();
})();
