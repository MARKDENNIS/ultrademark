/** @odoo-module **/

/*
 * Cosmetic backend URL debranding for Odoo 19.
 * Keeps the browser address bar and visible backend links on /admin even
 * though Odoo internally still resolves through its native /odoo backend route.
 */
(function () {
    "use strict";

    if (window.__orbinetBackendUrlDebrandingLoaded) {
        return;
    }
    window.__orbinetBackendUrlDebrandingLoaded = true;

    const nativePrefix = "/odoo";
    const brandedPrefix = "/admin";
    const brandedTitle = String(window.__webEnterpriseBrandTitle || "Orbinet ERP").trim() || "Orbinet ERP";
    let busy = false;

    function brandTitle() {
        if (!document.title || /odoo/i.test(document.title) || document.title !== brandedTitle) {
            document.title = brandedTitle;
        }
    }

    function nativePath(pathname) {
        return pathname === nativePrefix || pathname.startsWith(`${nativePrefix}/`);
    }

    function brandedPath(pathname) {
        return pathname === brandedPrefix || pathname.startsWith(`${brandedPrefix}/`);
    }

    function convert(urlLike, fromPrefix, toPrefix) {
        if (!urlLike) return urlLike;
        try {
            const original = String(urlLike);
            const url = new URL(original, window.location.origin);
            const isFrom = url.pathname === fromPrefix || url.pathname.startsWith(`${fromPrefix}/`);
            if (!isFrom) return urlLike;
            url.pathname = toPrefix + url.pathname.slice(fromPrefix.length);
            if (original.startsWith("http://") || original.startsWith("https://")) return url.href;
            return `${url.pathname}${url.search}${url.hash}`;
        } catch {
            return urlLike;
        }
    }

    function toBrand(urlLike) {
        return convert(urlLike, nativePrefix, brandedPrefix);
    }

    function toNative(urlLike) {
        return convert(urlLike, brandedPrefix, nativePrefix);
    }

    function brandAddress() {
        if (busy) return;
        if (!nativePath(window.location.pathname)) return;
        const branded = toBrand(window.location.href);
        if (branded && branded !== window.location.href) {
            busy = true;
            try {
                originalReplaceState.call(window.history, window.history.state, document.title, branded);
            } finally {
                busy = false;
            }
        }
    }

    function brandLinks(root) {
        const scope = root && root.querySelectorAll ? root : document;
        for (const node of scope.querySelectorAll('a[href^="/odoo"], a[href*="/odoo/"]')) {
            const href = node.getAttribute("href");
            const branded = toBrand(href);
            if (branded && branded !== href) node.setAttribute("href", branded);
        }
    }

    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;

    window.history.pushState = function (state, title, url) {
        return originalPushState.call(this, state, title, toBrand(url));
    };

    window.history.replaceState = function (state, title, url) {
        return originalReplaceState.call(this, state, title, toBrand(url));
    };

    // For hard navigation on branded backend links, send the request to native
    // route only at click time; the address is immediately branded again after boot.
    document.addEventListener("click", function (ev) {
        const link = ev.target.closest && ev.target.closest("a[href]");
        if (!link) return;
        const href = link.getAttribute("href");
        if (href && (href === brandedPrefix || href.startsWith(`${brandedPrefix}/`))) {
            const native = toNative(href);
            link.setAttribute("href", native);
            setTimeout(() => link.setAttribute("href", href), 0);
        }
    }, true);

    document.addEventListener("DOMContentLoaded", () => { brandTitle(); brandAddress(); brandLinks(document); });
    window.addEventListener("load", () => { brandTitle(); brandAddress(); });
    window.addEventListener("popstate", brandAddress);
    window.addEventListener("hashchange", brandAddress);

    if (window.MutationObserver) {
        new MutationObserver((records) => {
            for (const record of records) {
                for (const node of record.addedNodes || []) {
                    if (node.nodeType === Node.ELEMENT_NODE) brandLinks(node);
                }
            }
            brandAddress();
        }).observe(document.documentElement, { childList: true, subtree: true });
    }

    // Event-driven only; avoid rescanning every 500 ms.
    brandTitle();
    brandAddress();
})();
