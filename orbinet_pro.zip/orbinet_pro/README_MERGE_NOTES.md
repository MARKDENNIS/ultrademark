# Web Enterprise merged build

This build merges the useful Website Enterprise compatibility/debranding features back into `web_enterprise` while keeping `website` optional.

## Key changes

- `auto_install` is disabled so the module does not silently install itself.
- No dependency on `website` was added. Installing `web_enterprise` will not force Website installation.
- Optional website compatibility is applied at request time only when the `website` model exists:
  - `_control_third_party_trackers_in_html`
  - `_should_remove_third_party_trackers`
- Website/public debranding assets were copied into `orbinet_pro/static/src/website_debranding`.
- Login customization now uses uploaded binary images instead of URL/Data URI text fields:
  - Login background image
  - Login side image

## Install/update

Update the module list, then upgrade `web_enterprise`.
After upgrade, clear assets or restart the platform if old CSS/JS remains cached.
