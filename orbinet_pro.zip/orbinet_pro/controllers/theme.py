# -*- coding: utf-8 -*-
from odoo.http import Controller, Response, request, route


class WebEnterpriseThemeController(Controller):
    @route("/web_enterprise/chatter/config", type="http", auth="user", methods=["GET"], csrf=False)
    def chatter_config(self, **kwargs):
        enabled = request.env["ir.config_parameter"].sudo().get_param("web_enterprise.disable_chatter", "False").lower() in ("1", "true", "yes", "on")
        return Response('{"disabled": %s}' % ("true" if enabled else "false"), headers=[("Content-Type", "application/json; charset=utf-8"), ("Cache-Control", "no-store")])

    @route("/web_enterprise/theme.css", type="http", auth="user", methods=["GET"], csrf=False)
    def active_theme_css(self, **kwargs):
        profile = request.env["web.enterprise.theme.profile"].sudo().search([
            ("company_id", "=", request.env.company.id),
            ("active", "=", True),
            ("active_theme", "=", True),
        ], limit=1, order="sequence, id")
        css = profile.generated_css if profile else ""
        return Response(css or "", headers=[
            ("Content-Type", "text/css; charset=utf-8"),
            ("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0"),
        ])
