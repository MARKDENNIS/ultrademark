# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request


class EnterpriseExperienceController(http.Controller):
    @http.route('/web_enterprise/experience/config', type='jsonrpc', auth='user', methods=['POST'], csrf=False)
    def experience_config(self):
        params = request.env['ir.config_parameter'].sudo()

        def enabled(key, default=True):
            value = params.get_param(key, '1' if default else '0')
            return str(value).strip().lower() in {'1', 'true', 'yes', 'on'}

        density = params.get_param('web_enterprise.experience.density', 'comfortable')
        if density not in {'comfortable', 'compact'}:
            density = 'comfortable'
        return {
            'command_palette': enabled('web_enterprise.experience.command_palette'),
            'recent_commands': enabled('web_enterprise.experience.recent_commands'),
            'focus_mode': enabled('web_enterprise.experience.focus_mode'),
            'keyboard_shortcuts': enabled('web_enterprise.experience.keyboard_shortcuts'),
            'extension_sdk': enabled('web_enterprise.experience.extension_sdk'),
            'workspace_engine': enabled('web_enterprise.experience.workspace_engine'),
            'unified_search': enabled('web_enterprise.experience.unified_search'),
            'notification_center': enabled('web_enterprise.experience.notification_center'),
            'context_actions': enabled('web_enterprise.experience.context_actions'),
            'ai_workspace': enabled('web_enterprise.experience.ai_workspace'),
            'ai_shortcut': enabled('web_enterprise.experience.ai_shortcut'),
            'extension_manager': enabled('web_enterprise.experience.extension_manager'),
            'density': density,
        }
