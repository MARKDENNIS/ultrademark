# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request


class EnterpriseAIWorkspaceController(http.Controller):
    @http.route('/web_enterprise/ai/workspace', type='jsonrpc', auth='user', methods=['POST'], csrf=False)
    def workspace_config(self):
        params = request.env['ir.config_parameter'].sudo()
        enabled = str(params.get_param('web_enterprise.experience.ai_workspace', '1')).lower() in {'1', 'true', 'yes', 'on'}
        extension_enabled = str(params.get_param('web_enterprise.experience.extension_manager', '1')).lower() in {'1', 'true', 'yes', 'on'}
        if not enabled:
            return {'enabled': False, 'profiles': [], 'enabled_extensions': []}
        profiles = request.env['web.enterprise.ai.profile'].search([
            ('active', '=', True),
            '|', ('company_id', '=', False), ('company_id', '=', request.env.company.id),
        ])
        payload = [value for value in (profile.to_workspace_payload() for profile in profiles) if value]
        extensions = request.env['web.enterprise.extension'].enabled_keys() if extension_enabled else []
        return {
            'enabled': True,
            'shortcut': str(params.get_param('web_enterprise.experience.ai_shortcut', '1')).lower() in {'1', 'true', 'yes', 'on'},
            'profiles': payload,
            'enabled_extensions': extensions,
        }
