# -*- coding: utf-8 -*-
"""Lifecycle hooks for reliable fresh installs, upgrades and reinstalls."""

import logging

_logger = logging.getLogger(__name__)

_TABLES = {
    "web_enterprise_layout_profile": "id SERIAL PRIMARY KEY, model_id INTEGER",
    "web_enterprise_layout_rule": "id SERIAL PRIMARY KEY, model_id INTEGER",
    "web_enterprise_dashboard_profile": "id SERIAL PRIMARY KEY, company_id INTEGER",
    "web_enterprise_dashboard_widget": "id SERIAL PRIMARY KEY, dashboard_id INTEGER, model_id INTEGER",
    "web_enterprise_theme_profile": "id SERIAL PRIMARY KEY, company_id INTEGER",
    "web_enterprise_ai_profile": "id SERIAL PRIMARY KEY, company_id INTEGER",
    "web_enterprise_ai_prompt": "id SERIAL PRIMARY KEY, profile_id INTEGER, model_id INTEGER",
    "web_enterprise_extension": "id SERIAL PRIMARY KEY",
}


def pre_init_hook(env):
    """Create minimal relation-safe tables before stale metadata is processed."""
    for table, columns in _TABLES.items():
        env.cr.execute(f'CREATE TABLE IF NOT EXISTS "{table}" ({columns})')


def post_init_hook(env):
    """Normalize configuration and remove obsolete view metadata after install."""
    params = env['ir.config_parameter'].sudo()
    defaults = {
        'web_enterprise.branding_enabled': 'True',
        'web_enterprise.enterprise_extension_sdk': 'True',
        'web_enterprise.enterprise_workspace_engine': 'True',
    }
    for key, value in defaults.items():
        if params.get_param(key) is None:
            params.set_param(key, value)

    obsolete_xmlids = [
        'web_enterprise.res_config_settings_view_form_orbinet_legacy',
        'web_enterprise.res_config_settings_view_form_orbinet_212',
    ]
    for xmlid in obsolete_xmlids:
        record = env.ref(xmlid, raise_if_not_found=False)
        if record and record._name == 'ir.ui.view':
            record.sudo().unlink()


def uninstall_hook(env):
    """Remove generated views and framework parameters so reinstall starts cleanly."""
    generated = env['ir.ui.view'].sudo().search([
        '|',
        ('key', '=like', 'web_enterprise.generated_%'),
        ('name', '=like', 'Web Enterprise Generated%'),
    ])
    generated.unlink()
    env.cr.execute("DELETE FROM ir_config_parameter WHERE key LIKE 'web_enterprise.%'")
    _logger.info("Web Enterprise uninstall cleanup completed")
