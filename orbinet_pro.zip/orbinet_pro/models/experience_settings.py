# -*- coding: utf-8 -*-
"""System-wide, industry-neutral enterprise experience settings."""

from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    enterprise_command_palette = fields.Boolean(
        string="Universal command palette",
        config_parameter="web_enterprise.experience.command_palette",
        default=True,
        help="Open applications, menus, and registered commands from anywhere with Ctrl+K.",
    )
    enterprise_recent_commands = fields.Boolean(
        string="Recent commands",
        config_parameter="web_enterprise.experience.recent_commands",
        default=True,
        help="Keep a private browser-local list of recently opened commands.",
    )
    enterprise_focus_mode = fields.Boolean(
        string="Focus mode",
        config_parameter="web_enterprise.experience.focus_mode",
        default=True,
        help="Allow users to hide surrounding navigation and concentrate on the current workspace.",
    )
    enterprise_density = fields.Selection(
        selection=[
            ("comfortable", "Comfortable"),
            ("compact", "Compact"),
        ],
        string="Default interface density",
        config_parameter="web_enterprise.experience.density",
        default="comfortable",
    )
    enterprise_keyboard_shortcuts = fields.Boolean(
        string="Keyboard productivity shortcuts",
        config_parameter="web_enterprise.experience.keyboard_shortcuts",
        default=True,
        help="Enable framework-level navigation and productivity shortcuts.",
    )
    enterprise_extension_sdk = fields.Boolean(
        string="Frontend extension registry",
        config_parameter="web_enterprise.experience.extension_sdk",
        default=True,
        help="Expose stable registries that installed applications can use for commands and workspace contributions.",
    )





    enterprise_workspace_engine = fields.Boolean(
        string="Workspace contribution engine",
        config_parameter="web_enterprise.experience.workspace_engine",
        default=True,
    )
    enterprise_unified_search = fields.Boolean(
        string="Unified search providers",
        config_parameter="web_enterprise.experience.unified_search",
        default=True,
    )
    enterprise_notification_center = fields.Boolean(
        string="Enterprise notification providers",
        config_parameter="web_enterprise.experience.notification_center",
        default=True,
    )
    enterprise_context_actions = fields.Boolean(
        string="Context action providers",
        config_parameter="web_enterprise.experience.context_actions",
        default=True,
    )


    enterprise_layout_designer = fields.Boolean(
        string="No-code layout profiles",
        config_parameter="web_enterprise.experience.layout_designer",
        default=True,
        help="Allow system administrators to create reversible field-layout profiles without editing application source views.",
    )

    enterprise_dashboard_designer = fields.Boolean(
        string="No-code dashboard designer",
        config_parameter="web_enterprise.experience.dashboard_designer",
        default=True,
        help="Build reusable dashboards from KPIs, lists, shortcuts and information blocks.",
    )
    enterprise_theme_designer = fields.Boolean(
        string="Enterprise theme profiles",
        config_parameter="web_enterprise.experience.theme_designer",
        default=True,
        help="Create and apply company-aware visual themes without changing application source files.",
    )
    enterprise_ai_workspace = fields.Boolean(
        string="AI-ready workspace",
        config_parameter="web_enterprise.experience.ai_workspace",
        default=True,
        help="Expose a vendor-neutral assistant workspace that installed provider connectors and applications can extend.",
    )
    enterprise_ai_shortcut = fields.Boolean(
        string="AI workspace keyboard shortcut",
        config_parameter="web_enterprise.experience.ai_shortcut",
        default=True,
        help="Open the AI workspace with Ctrl+Shift+Space.",
    )
    enterprise_extension_manager = fields.Boolean(
        string="Extension manager",
        config_parameter="web_enterprise.experience.extension_manager",
        default=True,
        help="Manage and health-check framework extensions from one administration workspace.",
    )
