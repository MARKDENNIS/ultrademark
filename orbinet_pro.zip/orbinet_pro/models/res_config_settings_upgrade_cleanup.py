# -*- coding: utf-8 -*-
# Copyright 2026 Ultra Demark Technologies Ltd.
# License OPL-1 (the platform Proprietary License v1.0)

from lxml import etree

from odoo import api, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    @api.model
    def get_views(self, views, options=None):
        """Hide enterprise-upgrade-only settings without filtering Apps.

        This keeps the core platform Apps, app search, upgrades and installed
        modules untouched. It only removes settings entries rendered with the
        upgrade_boolean widget from the main Settings form.
        """
        result = super().get_views(views, options)
        form = result.get("views", {}).get("form")
        if not form or not form.get("arch"):
            return result

        form_view = self.env["ir.ui.view"].browse(form.get("id"))
        if form_view.xml_id != "base.res_config_settings_view_form":
            return result

        try:
            doc = etree.XML(form["arch"])
        except Exception:
            return result

        for setting in doc.xpath("//setting[field[@widget='upgrade_boolean']]"):
            classes = setting.attrib.get("class", "")
            if "d-none" not in classes.split():
                setting.attrib["class"] = (classes + " d-none").strip()

        for block in doc.xpath("//block"):
            visible_settings = block.xpath("setting[not(contains(concat(' ', normalize-space(@class), ' '), ' d-none ')) and not(@invisible='1')]")
            if not visible_settings:
                block.attrib.pop("title", None)
                block.attrib.pop("tip", None)
                classes = block.attrib.get("class", "")
                if "d-none" not in classes.split():
                    block.attrib["class"] = (classes + " d-none").strip()

        form["arch"] = etree.tostring(doc, encoding="unicode")
        return result
