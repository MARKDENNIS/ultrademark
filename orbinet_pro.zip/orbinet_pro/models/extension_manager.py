# -*- coding: utf-8 -*-
"""Extension catalogue, feature controls and health diagnostics."""
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class WebEnterpriseExtension(models.Model):
    _name = "web.enterprise.extension"
    _description = "Enterprise Framework Extension"
    _order = "category, sequence, name, id"

    name = fields.Char(required=True, translate=True)
    technical_key = fields.Char(required=True, index=True, copy=False)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    enabled = fields.Boolean(default=True)
    category = fields.Selection([
        ("core", "Core Experience"),
        ("navigation", "Navigation"),
        ("workspace", "Workspaces"),
        ("layout", "Layout and Forms"),
        ("dashboard", "Dashboards"),
        ("theme", "Themes"),
        ("ai", "AI and Automation"),
        ("integration", "Integration"),
        ("industry", "Industry Application"),
    ], default="integration", required=True)
    source_module = fields.Char(required=True, default="web_enterprise")
    version = fields.Char()
    description = fields.Text(translate=True)
    provider_key = fields.Char(help="Optional frontend registry or provider key exposed by this extension.")
    required_parameter = fields.Char(
        help="Optional ir.config_parameter key used to verify that the related framework feature is enabled.",
    )
    health_state = fields.Selection([
        ("unknown", "Not Checked"),
        ("healthy", "Healthy"),
        ("warning", "Attention Required"),
        ("disabled", "Disabled"),
        ("missing", "Source Module Missing"),
    ], default="unknown", readonly=True, copy=False)
    health_message = fields.Text(readonly=True, copy=False)
    last_health_check = fields.Datetime(readonly=True, copy=False)

    _technical_key_unique = models.Constraint(
        "unique(technical_key)",
        "Extension technical keys must be unique.",
    )

    @api.constrains("technical_key", "source_module", "provider_key")
    def _check_technical_values(self):
        for record in self:
            for field_name in ("technical_key", "source_module", "provider_key"):
                value = (record[field_name] or "").strip()
                if value and not all(char.isalnum() or char in "._-" for char in value):
                    raise ValidationError(_("%s contains unsupported characters.") % record._fields[field_name].string)

    def _module_is_installed(self):
        self.ensure_one()
        if self.source_module == "web_enterprise":
            return True
        module = self.env["ir.module.module"].sudo().search([("name", "=", self.source_module)], limit=1)
        return bool(module and module.state in ("installed", "to upgrade"))

    def action_health_check(self):
        params = self.env["ir.config_parameter"].sudo()
        for record in self:
            if not record.enabled:
                state, message = "disabled", _("Extension is disabled by the administrator.")
            elif not record._module_is_installed():
                state, message = "missing", _("Source module '%s' is not installed.") % record.source_module
            elif record.required_parameter:
                value = str(params.get_param(record.required_parameter, "1")).strip().lower()
                if value in ("0", "false", "no", "off"):
                    state, message = "warning", _("The related framework feature is disabled in system settings.")
                else:
                    state, message = "healthy", _("Extension source and required feature are available.")
            else:
                state, message = "healthy", _("Extension source is available.")
            record.write({
                "health_state": state,
                "health_message": message,
                "last_health_check": fields.Datetime.now(),
            })
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {"title": _("Extension Health Check"), "message": _("Health diagnostics completed."), "type": "success"},
        }

    def action_enable(self):
        self.write({"enabled": True, "health_state": "unknown", "health_message": False})

    def action_disable(self):
        self.write({"enabled": False, "health_state": "disabled", "health_message": _("Extension is disabled by the administrator.")})

    @api.model
    def enabled_keys(self):
        return self.sudo().search([("active", "=", True), ("enabled", "=", True)]).mapped("technical_key")
