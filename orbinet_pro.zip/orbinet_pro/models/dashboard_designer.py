# -*- coding: utf-8 -*-
"""Industry-neutral no-code dashboard profiles and widgets."""
from markupsafe import Markup, escape
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from odoo.tools.safe_eval import safe_eval


class WebEnterpriseDashboardProfile(models.Model):
    _name = "web.enterprise.dashboard.profile"
    _description = "Enterprise Dashboard Profile"
    _order = "sequence, name, id"

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, index=True)
    group_ids = fields.Many2many("res.groups", string="Visible to Groups", help="Leave empty to allow all internal users who can access the dashboard menu.")
    description = fields.Text(translate=True)
    widget_ids = fields.One2many("web.enterprise.dashboard.widget", "dashboard_id", string="Widgets", copy=True)
    preview_html = fields.Html(compute="_compute_preview_html", sanitize=False)
    widget_count = fields.Integer(compute="_compute_widget_count")

    @api.depends("widget_ids")
    def _compute_widget_count(self):
        for record in self:
            record.widget_count = len(record.widget_ids)

    def _user_can_open(self):
        self.ensure_one()
        if not self.group_ids:
            return True
        return bool(self.group_ids & self.env.user.groups_id)

    @api.depends(
        "name", "description", "widget_ids", "widget_ids.name", "widget_ids.widget_type",
        "widget_ids.model_id", "widget_ids.domain", "widget_ids.limit", "widget_ids.text_content",
        "widget_ids.action_id", "widget_ids.icon", "widget_ids.accent"
    )
    def _compute_preview_html(self):
        for record in self:
            cards = []
            for widget in record.widget_ids.sorted(lambda w: (w.sequence, w.id)):
                cards.append(widget._render_widget())
            empty = "" if cards else '<div class="o_we_dashboard_empty">Add widgets to build this dashboard.</div>'
            record.preview_html = Markup(
                '<section class="o_we_dashboard_preview">'
                '<header><div><h2>%s</h2><p>%s</p></div><span>%s</span></header>'
                '<div class="o_we_dashboard_grid">%s%s</div></section>'
            ) % (escape(record.name or _("Dashboard")), escape(record.description or ""),
                 escape(_("%s widgets") % len(record.widget_ids)), Markup("".join(str(c) for c in cards)), Markup(empty))

    def action_open_presentation(self):
        self.ensure_one()
        if not self._user_can_open():
            raise ValidationError(_("You do not have access to this dashboard."))
        return {
            "type": "ir.actions.act_window",
            "name": self.name,
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "views": [(self.env.ref("web_enterprise.web_enterprise_dashboard_profile_view_presentation").id, "form")],
            "target": "current",
            "context": {"dashboard_presentation": True},
        }


class WebEnterpriseDashboardWidget(models.Model):
    _name = "web.enterprise.dashboard.widget"
    _description = "Enterprise Dashboard Widget"
    _order = "sequence, id"

    dashboard_id = fields.Many2one("web.enterprise.dashboard.profile", required=True, ondelete="cascade", index=True)
    sequence = fields.Integer(default=10)
    name = fields.Char(required=True, translate=True)
    widget_type = fields.Selection([
        ("kpi", "KPI"),
        ("list", "Record List"),
        ("shortcut", "Action Shortcut"),
        ("text", "Information Block"),
    ], required=True, default="kpi")
    model_id = fields.Many2one("ir.model", string="Business Object", ondelete="cascade", domain="[('transient', '=', False)]")
    domain = fields.Char(default="[]", help="Optional the platform domain, for example [('active', '=', True)].")
    limit = fields.Integer(default=5)
    action_id = fields.Many2one("ir.actions.actions", string="Open Action", ondelete="set null")
    text_content = fields.Html(translate=True)
    icon = fields.Char(default="fa-bar-chart")
    accent = fields.Selection([
        ("primary", "Primary"), ("success", "Success"), ("warning", "Warning"),
        ("danger", "Danger"), ("info", "Information"), ("neutral", "Neutral"),
    ], default="primary", required=True)

    @api.constrains("domain")
    def _check_domain(self):
        for record in self:
            try:
                value = safe_eval(record.domain or "[]", {})
            except Exception as exc:
                raise ValidationError(_("Invalid widget domain: %s") % exc) from exc
            if not isinstance(value, (list, tuple)):
                raise ValidationError(_("Widget domain must be a list or tuple."))

    def _domain_value(self):
        self.ensure_one()
        try:
            value = safe_eval(self.domain or "[]", {})
            return value if isinstance(value, (list, tuple)) else []
        except Exception:
            return []

    def _model_records(self):
        self.ensure_one()
        if not self.model_id or self.model_id.model not in self.env:
            return self.env["res.users"].browse()
        model = self.env[self.model_id.model]
        try:
            model.check_access("read")
            return model.search(self._domain_value(), limit=max(1, min(self.limit or 5, 20)))
        except Exception:
            return model.browse()

    def _render_widget(self):
        self.ensure_one()
        title = escape(self.name or _("Widget"))
        css = "o_we_dashboard_card o_we_accent_%s" % (self.accent or "primary")
        icon = escape(self.icon or "fa-square-o")
        if self.widget_type == "text":
            body = Markup(self.text_content or '<p class="text-muted">No information entered.</p>')
        elif self.widget_type == "shortcut":
            label = escape(self.action_id.name if self.action_id else _("Configure an action"))
            body = Markup('<div class="o_we_shortcut"><i class="fa %s"></i><span>%s</span></div>') % (icon, label)
        elif self.widget_type == "list":
            records = self._model_records()
            rows = "".join('<li>%s</li>' % escape(rec.display_name) for rec in records)
            body = Markup('<ul class="o_we_record_list">%s</ul>') % Markup(rows or '<li class="text-muted">No records</li>')
        else:
            count = 0
            if self.model_id and self.model_id.model in self.env:
                try:
                    model = self.env[self.model_id.model]
                    model.check_access("read")
                    count = model.search_count(self._domain_value())
                except Exception:
                    count = 0
            body = Markup('<div class="o_we_kpi"><strong>%s</strong><span>%s</span></div>') % (escape(str(count)), escape(self.model_id.name if self.model_id else _("Records")))
        return Markup('<article class="%s"><div class="o_we_card_title"><i class="fa %s"></i><span>%s</span></div><div class="o_we_card_body">%s</div></article>') % (css, icon, title, body)
