# -*- coding: utf-8 -*-
from odoo import models
from odoo.release import version_info


class PublisherWarrantyContract(models.AbstractModel):
    _inherit = "publisher_warranty.contract"

    def update_notification(self, cron_mode=True):
        """Disable the platform online publisher notification in Community, keep Enterprise behavior."""
        if len(version_info) > 5 and version_info[5] == "e":
            return super().update_notification(cron_mode=cron_mode)
        return True
