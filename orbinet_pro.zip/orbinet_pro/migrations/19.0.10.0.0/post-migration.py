# -*- coding: utf-8 -*-

def migrate(cr, version):
    # Clear only stale compiled asset attachments; the platform rebuilds them on demand.
    cr.execute("""
        DELETE FROM ir_attachment
         WHERE url LIKE '/web/assets/%'
           AND name LIKE '%web_enterprise%'
    """)
