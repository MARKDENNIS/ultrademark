# Mixed-content hardening

This build prevents browser-facing branding settings from emitting insecure resources.

- Login CTA URLs now allow only HTTPS or same-origin relative paths.
- Company, powered-by and promotional URLs are sanitized at render time.
- Login custom CSS removes insecure `http://` and protocol-relative imports/URLs.
- Script/style injection patterns in custom CSS are rejected.
- Mail footer replacement URLs now require HTTPS.
- Existing insecure values in `ir.config_parameter` are handled safely without a manual database cleanup.

SVG namespace declarations using `http://www.w3.org/2000/svg` are XML identifiers and do not make network requests.
