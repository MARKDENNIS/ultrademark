/* Thriving Teens Foundation — site scripts (no dependencies) */
(function () {
  'use strict';
  var ROOT = document.body.getAttribute('data-root') || '';
  var EMAIL = 'info@thrivingteensfoundation.org';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  /* ---------- Toast ---------- */
  function toast(msg) {
    var t = $('#toast'); if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(window.__toast);
    window.__toast = setTimeout(function () { t.classList.remove('show'); }, 3200);
  }
  window.ttfToast = toast;

  /* ---------- Year ---------- */
  $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- Mobile menu & dropdowns ---------- */
  var menu = $('#menu'), toggle = $('.menu-toggle');
  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      var open = menu.classList.toggle('mobile-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.style.overflow = open ? 'hidden' : '';
    });
  }
  $$('.nav-dropdown > button').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (window.innerWidth > 980) return;
      e.preventDefault();
      var dd = btn.parentElement, open = !dd.classList.contains('open');
      $$('.nav-dropdown').forEach(function (d) { d.classList.remove('open'); d.firstElementChild.setAttribute('aria-expanded', 'false'); });
      if (open) { dd.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); }
    });
  });
  window.addEventListener('resize', function () {
    if (window.innerWidth > 980 && menu) { menu.classList.remove('mobile-open'); document.body.style.overflow = ''; }
  });

  /* ---------- Nairobi clock ---------- */
  function tickClock() {
    $$('[data-clock]').forEach(function (el) {
      try {
        var fmt = new Intl.DateTimeFormat('en-KE', {
          timeZone: 'Africa/Nairobi', weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
          hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
        });
        el.textContent = fmt.format(new Date()) + ' EAT';
      } catch (err) {
        el.textContent = new Date().toLocaleString();
      }
    });
  }
  tickClock();
  setInterval(tickClock, 1000);

  /* ---------- Search (top bar) ---------- */
  var input = $('#searchInput'), results = $('#searchResults');
  var INDEX = window.TTF_INDEX || [];
  function openSearch() { if (input) { input.focus(); runSearch(); } }
  function closeSearch() { if (results) results.hidden = true; }
  function norm(s) { return (s || '').toLowerCase(); }
  function runSearch() {
    if (!results || !input) return;
    var q = norm(input.value).trim();
    if (!q) { results.hidden = true; results.innerHTML = ''; return; }
    var words = q.split(/\s+/);
    var list = INDEX.map(function (it) {
      var hay = norm(it.t + ' ' + it.k + ' ' + it.c), score = 0;
      words.forEach(function (w) { if (hay.indexOf(w) > -1) score += 1; if (norm(it.t).indexOf(w) > -1) score += 2; });
      return { it: it, s: score };
    }).filter(function (x) { return x.s >= words.length; }).sort(function (a, b) { return b.s - a.s; }).map(function (x) { return x.it; });
    results.hidden = false;
    if (!list.length) { results.innerHTML = '<p>No results for “' + escapeHtml(input.value) + '”.</p>'; return; }
    results.innerHTML = list.slice(0, 8).map(function (it) {
      return '<a href="' + ROOT + it.u + '"><strong>' + escapeHtml(it.t) + '</strong><small>' + escapeHtml(it.c) + '</small></a>';
    }).join('');
  }
  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); }
  $$('[data-open-search]').forEach(function (b) { b.addEventListener('click', function () { openSearch(); }); });
  if (input) {
    input.addEventListener('input', runSearch);
    input.addEventListener('focus', function () { if (input.value.trim()) runSearch(); });
  }
  document.addEventListener('click', function (e) {
    var wrap = $('.topbar-search-wrap');
    if (wrap && !wrap.contains(e.target)) closeSearch();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { closeSearch(); if (menu) { menu.classList.remove('mobile-open'); document.body.style.overflow = ''; } }
    var tag = (document.activeElement && document.activeElement.tagName) || '';
    if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(tag)) { e.preventDefault(); openSearch(); }
  });

  /* ---------- Youth Resource Navigator ---------- */
  var NAV = {
    question: { t: 'Got a question? Ask it — no judgement.', d: 'Browse honest answers to common questions or send us your own. You don’t have to share your name.', l: [['teens.html#ask', 'Ask us anything', 'Send a question to our team'], ['teens.html#faq', 'Teen FAQs', 'Quick answers to common questions'], ['stories.html', 'Read our articles', 'Health, relationships & more']] },
    self: { t: 'Understanding yourself', d: 'Your body, feelings and identity are changing — and that is normal. Start here.', l: [['blog/menstruation.html', 'Myths about menstruation', 'Facts every teen should know'], ['programmes.html#dtd', 'Dancing Thru’ Development', 'Our programme for ages 13–14'], ['teens.html#topics', 'Explore teen topics', 'Body, mind, relationships, future']] },
    relationships: { t: 'Friendships & relationships', d: 'Healthy relationships are built on respect, trust and clear communication.', l: [['blog/friendship.html', 'We’re not fighting, right?', 'Handling conflict in friendships'], ['programmes.html#groove', 'Love Life Fiesta sessions', 'Relationships & consent (17–19)'], ['teens.html#faq', 'Relationship FAQs', 'Boundaries, consent, pressure']] },
    health: { t: 'Understanding your health', d: 'Accurate, age-appropriate health information — including support if you live with a condition.', l: [['blog/hpv-vaccine.html', 'The HPV vaccine explained', 'What teens & parents need to know'], ['blog/immunisation.html', 'Why immunisation still matters', 'Vaccines in your teenage years'], ['work.html#conditions', 'We See You', 'Living with a chronic condition']] },
    confidence: { t: 'Building confidence', d: 'Confidence grows when you know yourself, your values and your choices.', l: [['blog/vaping.html', 'Saying no to pressure', 'Vaping, smoking & substance use'], ['blog/kevin.html', 'Living fully: Kevin’s story', 'A journey of courage'], ['programmes.html#vibe', 'Vibe & Bloom', 'Our programme for ages 15–16']] },
    school: { t: 'Help with school', d: 'Stay in school, stay curious — and know your right to education.', l: [['resources.html', 'Resource Centre', 'Guides, articles & tools'], ['advocacy.html#education', 'Right to education', 'Including school re-entry'], ['programmes.html', 'Life-skills programmes', 'Study, focus & goal setting']] },
    future: { t: 'Thinking about your future', d: 'Careers, personal branding and leaving home — plan your next chapter with confidence.', l: [['programmes.html#groove', 'Groove-n-Grow (17–19)', 'Career, mentorship & branding'], ['blog/groove-fiesta.html', 'Inside the Groove n Grow Fiesta', 'What participants learned'], ['involved.html#mentor', 'Find a mentor', 'Or become one']] },
    rights: { t: 'Knowing your rights', d: 'Every adolescent has the right to health, safety, education and protection from harmful practices.', l: [['advocacy.html', 'Our advocacy', 'Rights we stand up for'], ['safeguarding.html', 'Staying safe', 'How we protect young people'], ['teens.html#help', 'Get help now', 'Free, confidential helplines']] },
    talk: { t: 'You deserve someone to talk to', d: 'If you are struggling, you are not alone. These free, confidential services are here for you — 24/7 where marked.', l: [['teens.html#help', 'Helplines (free)', 'Childline 116 · Befrienders Kenya'], ['teens.html#ask', 'Message our team', 'We’ll point you to support'], ['contact.html', 'Contact us', 'Email or call the office']] },
    skills: { t: 'Developing life skills', d: 'Communication, decision-making, coping with stress and planning ahead — skills for life.', l: [['programmes.html', 'Our programmes', 'Age-based life-skills journeys'], ['blog/groove-fiesta.html', 'Groove n Grow Fiesta report', 'Skills from our training'], ['resources.html', 'Resource Centre', 'Tools for everyday life']] }
  };
  var navResult = $('#navResult');
  $$('.option[data-key]').forEach(function (opt) {
    opt.addEventListener('click', function () {
      $$('.option').forEach(function (o) { o.classList.remove('selected'); o.setAttribute('aria-pressed', 'false'); });
      opt.classList.add('selected'); opt.setAttribute('aria-pressed', 'true');
      var d = NAV[opt.getAttribute('data-key')]; if (!d || !navResult) return;
      var arrow = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
      navResult.innerHTML = '<h3>' + d.t + '</h3><p>' + d.d + '</p><div class="nav-links">' + d.l.map(function (x) {
        return '<a href="' + ROOT + x[0] + '">' + arrow + '<span>' + x[1] + '<small>' + x[2] + '</small></span></a>';
      }).join('') + '</div>';
      navResult.classList.add('show');
      if (window.innerWidth < 820) navResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  });

  /* ---------- Forms (endpoint if configured, otherwise email fallback) ---------- */
  $$('form[data-form]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var kind = form.getAttribute('data-form');
      var subject = form.getAttribute('data-subject') || ('Website enquiry: ' + kind);
      var endpoint = form.getAttribute('data-endpoint');
      var fd = new FormData(form);
      var ok = form.querySelector('.form-success');
      function done(msg) {
        if (ok) { ok.textContent = msg; ok.classList.add('show'); }
        toast(msg); form.reset();
        $$('.amount', form).forEach(function (a, i) { a.classList.toggle('on', i === 1); });
      }
      if (endpoint) {
        fetch(endpoint, { method: 'POST', body: fd, headers: { Accept: 'application/json' } })
          .then(function (r) { if (!r.ok) throw 0; done(form.getAttribute('data-success') || 'Thank you — we have received your message.'); })
          .catch(function () { toast('Sorry, something went wrong. Please email ' + EMAIL); });
        return;
      }
      var lines = [];
      fd.forEach(function (v, k) { if (k.charAt(0) !== '_' && String(v).trim()) lines.push(k.replace(/_/g, ' ') + ': ' + v); });
      window.location.href = 'mailto:' + EMAIL + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(lines.join('\n') + '\n\n— Sent from thrivingteensfoundation.org');
      done(form.getAttribute('data-success') || 'Thank you! Your email app will open so you can send your message.');
    });
  });

  /* ---------- Filters (stories, resources) ---------- */
  $$('[data-filter-group]').forEach(function (group) {
    var target = $(group.getAttribute('data-filter-group'));
    if (!target) return;
    var items = $$('[data-cat]', target), current = 'all', q = '';
    var empty = $('.empty', target.parentElement);
    function apply() {
      var shown = 0;
      items.forEach(function (it) {
        var cats = (it.getAttribute('data-cat') || '').split(' ');
        var okCat = current === 'all' || cats.indexOf(current) > -1;
        var okQ = !q || norm(it.textContent).indexOf(q) > -1;
        var show = okCat && okQ; it.style.display = show ? '' : 'none'; if (show) shown++;
      });
      if (empty) empty.style.display = shown ? 'none' : 'block';
    }
    $$('.filter-btn', group).forEach(function (b) {
      b.addEventListener('click', function () {
        $$('.filter-btn', group).forEach(function (x) { x.classList.remove('on'); x.setAttribute('aria-pressed', 'false'); });
        b.classList.add('on'); b.setAttribute('aria-pressed', 'true'); current = b.getAttribute('data-filter'); apply();
      });
    });
    var s = $('input[data-filter-search]', group);
    if (s) s.addEventListener('input', function () { q = norm(s.value).trim(); apply(); });
    var hash = (location.hash || '').replace('#', '');
    var pre = hash && $('.filter-btn[data-filter="' + hash + '"]', group);
    if (pre) pre.click();
  });

  /* ---------- Awareness calendar (auto-updates every year) ---------- */
  var DAYS = [
    [1, 24, 'International Day of Education', 'Every adolescent’s right to learn — including young mothers returning to school.', 'Education'],
    [2, 4, 'World Cancer Day', 'Prevention starts young: HPV vaccination protects against cervical cancer.', 'Health'],
    [3, 4, 'International HPV Awareness Day', 'Busting HPV vaccine myths with parents, teens and schools.', 'Health'],
    [3, 8, 'International Women’s Day', 'Rights, equality and empowerment for every girl.', 'Rights'],
    [3, 20, 'International Day of Happiness', 'Wellbeing, joy and connection for young people.', 'Wellbeing'],
    [4, 2, 'World Autism Awareness Day', 'Celebrating neurodivergent teens and their unique paths.', 'Inclusion'],
    [4, 7, 'World Health Day', 'Adolescent health belongs on every health agenda.', 'Health'],
    [4, 24, 'World Immunization Week (24–30 Apr)', 'Why immunisation still matters in the teenage years.', 'Health'],
    [5, 28, 'Menstrual Hygiene Day', 'Dignity and period facts — including for adolescents with disabilities.', 'Health'],
    [5, 31, 'World No Tobacco Day', 'Real talk on vaping, nicotine pouches and peer pressure.', 'Wellbeing'],
    [6, 12, 'World Day Against Child Labour', 'Child labour is immoral and offends the law.', 'Rights'],
    [6, 16, 'Day of the African Child', 'Championing the rights of Africa’s children and adolescents.', 'Rights'],
    [6, 19, 'World Sickle Cell Day', 'Standing with teens living with sickle cell disease.', 'Chronic conditions'],
    [6, 26, 'International Day Against Drug Abuse', 'Supporting young people to make informed, healthy choices.', 'Wellbeing'],
    [8, 12, 'International Youth Day', 'Youth voice, leadership and participation.', 'Youth voice'],
    [9, 10, 'World Suicide Prevention Day', 'You are not alone — reaching out is a sign of strength.', 'Mental health'],
    [9, 26, 'World Contraception Day', 'Accurate, age-appropriate sexual & reproductive health information.', 'Health'],
    [9, 29, 'World Heart Day', 'With every heartbeat, we walk beside teens living with heart conditions.', 'Chronic conditions'],
    [10, 10, 'World Mental Health Day', 'Mental wellbeing is part of every young person’s health.', 'Mental health'],
    [10, 11, 'International Day of the Girl Child', 'Girls’ rights, voice and potential.', 'Rights'],
    [11, 14, 'World Diabetes Day', 'More than needles and starch portions — thriving with diabetes.', 'Chronic conditions'],
    [11, 20, 'World Children’s Day', 'Every child deserves a safe transition through adolescence.', 'Rights'],
    [11, 25, '16 Days of Activism (25 Nov – 10 Dec)', 'Ending gender-based violence against girls and young women.', 'Rights'],
    [12, 1, 'World AIDS Day', 'Knowledge, compassion and support transform lives.', 'Chronic conditions'],
    [12, 3, 'International Day of Persons with Disabilities', 'Inclusive health and education for adolescents with disabilities.', 'Inclusion']
  ];
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function upcoming() {
    var now = new Date(); now.setHours(0, 0, 0, 0);
    return DAYS.map(function (d) {
      var dt = new Date(now.getFullYear(), d[0] - 1, d[1]);
      if (dt < now) dt = new Date(now.getFullYear() + 1, d[0] - 1, d[1]);
      return { date: dt, days: Math.round((dt - now) / 864e5), title: d[2], text: d[3], tag: d[4] };
    }).sort(function (a, b) { return a.date - b.date; });
  }
  function rel(n) { return n === 0 ? 'Today' : n === 1 ? 'Tomorrow' : 'In ' + n + ' days'; }
  var nextBox = $('[data-next-event]');
  if (nextBox) {
    var n = upcoming()[0];
    $('[data-ne-day]', nextBox).textContent = n.date.getDate();
    $('[data-ne-mon]', nextBox).textContent = MON[n.date.getMonth()];
    $('[data-ne-title]', nextBox).textContent = n.title;
    $('[data-ne-text]', nextBox).textContent = n.text;
    $('[data-ne-when]', nextBox).textContent = rel(n.days);
  }
  var cal = $('#awarenessList');
  if (cal) {
    var limit = parseInt(cal.getAttribute('data-limit') || '12', 10);
    cal.innerHTML = upcoming().slice(0, limit).map(function (e) {
      return '<div class="event-row' + (e.days <= 14 ? ' soon' : '') + '"><div class="date-box"><strong>' + e.date.getDate() + '</strong><small>' + MON[e.date.getMonth()] + '</small></div>' +
        '<div><h3>' + e.title + '</h3><p>' + e.text + '</p></div><div class="when">' + rel(e.days) + ' · ' + e.tag + '</div></div>';
    }).join('');
  }

  /* ---------- Donate UI ---------- */
  var IMPACT = { 1000: 'helps print take-home learning materials for a workshop participant', 2500: 'helps cover a young person’s place at a life-skills session', 5000: 'helps fund a parent & caregiver capacity-building session', 10000: 'helps a mentor reach a full group of adolescents', 25000: 'helps bring a programme day to a school or community group', 50000: 'helps fund research that shapes better adolescent health services' };
  $$('[data-donate]').forEach(function (box) {
    var hidden = $('input[name="Amount_KES"]', box), custom = $('input[name="Custom_amount"]', box), line = $('[data-impact]', box), freq = $('input[name="Frequency"]', box);
    function setAmt(v) {
      if (hidden) hidden.value = v;
      if (line) line.textContent = 'KES ' + Number(v).toLocaleString() + (freq && freq.value === 'Monthly' ? ' a month ' : ' ') + (IMPACT[v] || 'goes straight to programmes for adolescents in Kenya');
    }
    $$('.amount', box).forEach(function (b) {
      b.addEventListener('click', function () { $$('.amount', box).forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); if (custom) custom.value = ''; setAmt(b.getAttribute('data-v')); });
    });
    if (custom) custom.addEventListener('input', function () { if (custom.value) { $$('.amount', box).forEach(function (x) { x.classList.remove('on'); }); setAmt(custom.value); } });
    $$('.seg button', box).forEach(function (b) {
      b.addEventListener('click', function () { $$('.seg button', box).forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); if (freq) freq.value = b.getAttribute('data-f'); setAmt(hidden.value); });
    });
    setAmt(hidden ? hidden.value : 2500);
  });

  /* ---------- Count-up numbers ---------- */
  function countUp(el) {
    var end = parseFloat(el.getAttribute('data-count')), suf = el.getAttribute('data-suffix') || '', dur = 1200, t0 = null;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = end + suf; return; }
    function step(ts) { if (!t0) t0 = ts; var p = Math.min((ts - t0) / dur, 1); el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))) + suf; if (p < 1) requestAnimationFrame(step); }
    requestAnimationFrame(step);
  }

  /* ---------- Reveal on scroll ---------- */
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.classList.add('in');
        if (en.target.hasAttribute('data-count')) countUp(en.target);
        io.unobserve(en.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    $$('.reveal, [data-count]').forEach(function (el) { io.observe(el); });

    /* sub-nav highlight */
    var links = $$('.subnav a[href^="#"]');
    if (links.length) {
      var so = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) links.forEach(function (a) { a.classList.toggle('on', a.getAttribute('href') === '#' + en.target.id); });
        });
      }, { rootMargin: '-45% 0px -50% 0px' });
      links.forEach(function (a) { var t = $(a.getAttribute('href')); if (t) so.observe(t); });
    }
  } else {
    $$('.reveal').forEach(function (el) { el.classList.add('in'); });
    $$('[data-count]').forEach(function (el) { el.textContent = el.getAttribute('data-count') + (el.getAttribute('data-suffix') || ''); });
  }

  /* ---------- Back to top ---------- */
  var top = $('.to-top');
  if (top) {
    window.addEventListener('scroll', function () { top.classList.toggle('show', window.scrollY > 700); }, { passive: true });
    top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  /* ---------- Account (static demo, this browser) ---------- */
  var USERS_KEY = 'ttf_users';
  var SESS_KEY = 'ttf_session';
  var RESET_KEY = 'ttf_reset';
  function accUsers() {
    try { return JSON.parse(localStorage.getItem(USERS_KEY) || '[]'); } catch (e) { return []; }
  }
  function accSaveUsers(list) { localStorage.setItem(USERS_KEY, JSON.stringify(list)); }
  function accSession() {
    try { return JSON.parse(localStorage.getItem(SESS_KEY) || 'null'); } catch (e) { return null; }
  }
  function accSetSession(u) {
    if (u) {
      var rec = { email: u.email, name: u.name, last: new Date().toISOString() };
      localStorage.setItem(SESS_KEY, JSON.stringify(rec));
      return rec;
    }
    localStorage.removeItem(SESS_KEY);
    return null;
  }
  function accAlert(msg, ok) {
    var el = $('#ttf-acc-alert');
    if (!el) { toast(msg); return; }
    el.hidden = !msg;
    el.textContent = msg || '';
    el.className = 'ttf-acc-alert ' + (ok ? 'is-ok' : 'is-err');
  }
  function accStrong(p) {
    return p && p.length >= 8 && /[A-Za-z]/.test(p) && /\d/.test(p);
  }
  function accPaintHeader() {
    var s = accSession();
    $$('.js-acc-link').forEach(function (a) {
      a.textContent = s ? 'Account' : 'Log in';
    });
  }
  accPaintHeader();
  $$('[data-toggle-pass]').forEach(function (b) {
    b.addEventListener('click', function () {
      var inp = document.getElementById(b.getAttribute('data-toggle-pass'));
      if (!inp) return;
      inp.type = inp.type === 'password' ? 'text' : 'password';
      b.textContent = inp.type === 'password' ? 'Show' : 'Hide';
    });
  });
  $$('[data-pw-meter]').forEach(function (hint) {
    var inp = document.getElementById(hint.getAttribute('data-pw-meter'));
    if (!inp) return;
    inp.addEventListener('input', function () {
      hint.textContent = accStrong(inp.value) ? 'Looks good.' : 'Use 8+ characters with letters and a number.';
    });
  });
  function accTitles(view) {
    var map = {
      login: ['Sign in', 'Use your Thriving Teens account to manage details and donations.'],
      register: ['Create an account', 'One account for donations, updates and programme interest.'],
      forgot: ['Reset password', 'We will help you choose a new password if the email is on file.'],
      'forgot-sent': ['Check your inbox', 'For your privacy we do not say whether that email is registered.'],
      reset: ['New password', 'Choose a unique password you do not reuse elsewhere.']
    };
    var t = map[view] || map.login;
    var h = $('#ttf-acc-title'), l = $('#ttf-acc-lead');
    if (h) h.textContent = t[0];
    if (l) l.textContent = t[1];
  }
  function accView(name) {
    accAlert('', true);
    $$('[data-acc-view]').forEach(function (el) { el.hidden = el.getAttribute('data-acc-view') !== name; });
    accTitles(name);
    if (location.hash.replace('#', '') !== name && { login: 1, register: 1, forgot: 1, reset: 1 }[name]) {
      history.replaceState(null, '', '#' + name);
    }
  }
  function accFillDash(s) {
    $$('[data-acc-name]').forEach(function (el) { el.textContent = s.name || 'there'; });
    $$('[data-acc-email]').forEach(function (el) { el.textContent = s.email || ''; });
    $$('[data-acc-last]').forEach(function (el) {
      try { el.textContent = s.last ? new Date(s.last).toLocaleString('en-KE') : 'just now'; } catch (e) { el.textContent = 'just now'; }
    });
    var pfN = $('#pf-name'), pfE = $('#pf-email');
    if (pfN) pfN.value = s.name || '';
    if (pfE) pfE.value = s.email || '';
  }
  function accShowDash(s) {
    var auth = $('#ttf-auth'), dash = $('#ttf-dash');
    if (!dash && !auth) return;
    if (s) {
      if (auth) auth.hidden = true;
      if (dash) { dash.hidden = false; dash.style.display = 'grid'; }
      accFillDash(s);
      accDashPanel('overview');
      var h = $('#ttf-acc-title'), l = $('#ttf-acc-lead');
      if (h) h.textContent = 'Your account';
      if (l) l.textContent = 'Manage profile, password and sign-in on this device.';
    } else {
      if (auth) auth.hidden = false;
      if (dash) { dash.hidden = true; dash.style.display = 'none'; }
      var hash = (location.hash || '#login').replace('#', '');
      if (hash === 'register' || hash === 'forgot' || hash === 'reset' || hash === 'forgot-sent') accView(hash);
      else accView('login');
    }
  }
  accShowDash(accSession());
  window.addEventListener('hashchange', function () {
    if (accSession()) return;
    var h = (location.hash || '#login').replace('#', '');
    if (h === 'register' || h === 'forgot' || h === 'reset' || h === 'login') accView(h);
  });
  var loginF = $('#ttf-login');
  if (loginF) loginF.addEventListener('submit', function (e) {
    e.preventDefault();
    var email = ($('#li-email').value || '').trim().toLowerCase();
    var pass = $('#li-pass').value || '';
    var u = accUsers().filter(function (x) { return x.email === email && x.pass === pass; })[0];
    if (!u) { accAlert('That email or password is not right.'); return; }
    var s = accSetSession(u);
    accPaintHeader();
    accShowDash(s);
    accAlert('Welcome back.', true);
  });
  var regF = $('#ttf-register');
  if (regF) regF.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = ($('#rg-name').value || '').trim();
    var email = ($('#rg-email').value || '').trim().toLowerCase();
    var pass = $('#rg-pass').value || '';
    var pass2 = $('#rg-pass2').value || '';
    if (!accStrong(pass)) { accAlert('Use 8+ characters with letters and a number.'); return; }
    if (pass !== pass2) { accAlert('Passwords do not match.'); return; }
    var list = accUsers();
    if (list.some(function (x) { return x.email === email; })) { accAlert('Could not create that account. Try signing in or resetting your password.'); return; }
    var u = { name: name, email: email, pass: pass };
    list.push(u);
    accSaveUsers(list);
    var s = accSetSession(u);
    accPaintHeader();
    accShowDash(s);
    accAlert('Account created.', true);
  });
  var lostF = $('#ttf-lost');
  if (lostF) lostF.addEventListener('submit', function (e) {
    e.preventDefault();
    var email = ($('#ls-email').value || '').trim().toLowerCase();
    var u = accUsers().filter(function (x) { return x.email === email; })[0];
    if (u) localStorage.setItem(RESET_KEY, JSON.stringify({ email: email, at: Date.now() }));
    accView('forgot-sent');
  });
  var resetF = $('#ttf-reset');
  if (resetF) resetF.addEventListener('submit', function (e) {
    e.preventDefault();
    var pass = $('#rs-pass').value || '';
    var pass2 = $('#rs-pass2').value || '';
    if (!accStrong(pass)) { accAlert('Use 8+ characters with letters and a number.'); return; }
    if (pass !== pass2) { accAlert('Passwords do not match.'); return; }
    var tok;
    try { tok = JSON.parse(localStorage.getItem(RESET_KEY) || 'null'); } catch (err) { tok = null; }
    if (!tok || !tok.email) { accAlert('This reset link is not valid. Request a new one.'); accView('forgot'); return; }
    var list = accUsers();
    var found = false;
    list.forEach(function (x) { if (x.email === tok.email) { x.pass = pass; found = true; } });
    if (!found) { accAlert('This reset link is not valid. Request a new one.'); accView('forgot'); return; }
    accSaveUsers(list);
    localStorage.removeItem(RESET_KEY);
    accView('login');
    accAlert('Password updated. Sign in with your new password.', true);
  });
  var lo = $('#ttf-logout');
  if (lo) lo.addEventListener('click', function () {
    accSetSession(null);
    accPaintHeader();
    accShowDash(null);
    accAlert('You have been signed out.', true);
  });
  function accDashPanel(id) {
    $$('[data-dash]').forEach(function (x) { x.classList.toggle('on', x.getAttribute('data-dash') === id); });
    $$('[data-dash-panel]').forEach(function (p) {
      var show = p.getAttribute('data-dash-panel') === id;
      p.hidden = !show;
      p.style.display = show ? 'block' : 'none';
    });
  }
  $$('[data-dash]').forEach(function (b) {
    b.addEventListener('click', function () { accDashPanel(b.getAttribute('data-dash')); });
  });
  var pf = $('#ttf-profile');
  if (pf) pf.addEventListener('submit', function (e) {
    e.preventDefault();
    var s = accSession(); if (!s) return;
    var name = ($('#pf-name').value || '').trim();
    var list = accUsers();
    list.forEach(function (x) { if (x.email === s.email) x.name = name; });
    accSaveUsers(list);
    s.name = name;
    localStorage.setItem(SESS_KEY, JSON.stringify(s));
    accFillDash(s);
    accPaintHeader();
    accAlert('Profile saved.', true);
  });
  var sc = $('#ttf-security');
  if (sc) sc.addEventListener('submit', function (e) {
    e.preventDefault();
    var s = accSession(); if (!s) return;
    var cur = $('#sc-current').value || '';
    var pass = $('#sc-pass').value || '';
    var pass2 = $('#sc-pass2').value || '';
    var u = accUsers().filter(function (x) { return x.email === s.email; })[0];
    if (!u || u.pass !== cur) { accAlert('Current password is not right.'); return; }
    if (!accStrong(pass)) { accAlert('Use 8+ characters with letters and a number.'); return; }
    if (pass !== pass2) { accAlert('Passwords do not match.'); return; }
    var list = accUsers();
    list.forEach(function (x) { if (x.email === s.email) x.pass = pass; });
    accSaveUsers(list);
    accAlert('Password updated.', true);
    sc.reset();
  });

  /* ---------- Org chart bios ---------- */
  var ORG_BIOS = {
    board: { name: 'Board of Management', role: 'Governance', img: 'assets/img/team/tom.jpg', text: 'The Board sets strategy and oversight. Tap a member’s name under BOARD to read their bio.' },
    tom: { name: 'Tom Mshindi', role: 'Board Chair', img: 'assets/img/team/tom.jpg', text: 'Mr. Tom Mshindi is a communications expert in media and development communication. He is a communications and business management graduate, previously worked as the Editor-in-Chief at the Nation Media Group, Senior Editor at the Standard Media Group and other leading media houses in Uganda and Tanzania. He worked for UNICEF as the Chief of Communications for the UNICEF Nigeria office. His work at the UN and as a consultant for the International Planned Parenthood Association and the World Bank fostered a strong interest in children and adolescent health.' },
    lisa: { name: 'Dr. Lisa Noguchi', role: 'Board Member', img: 'assets/img/team/lisa.jpg', text: 'Dr. Noguchi, CNM, PhD, is an infectious disease epidemiologist and certified nurse-midwife with over 20 years of experience in maternal newborn health, research, and program implementation in the U.S., Asia, Africa, Latin America and the Caribbean. She supports COVID-19 response activities for maternal newborn health services within the USAID-funded MOMENTUM Country and Global Leadership Project and preparations for the International Maternal Newborn Health Conference by the Jhpiego Secretariat of AlignMNH.' },
    chris: { name: 'Dr. Chris Barasa', role: 'Board Member', img: 'assets/img/team/chris.jpg', text: 'Dr Chris is a Medical Doctor and a Health Systems Specialist with over 16 years’ experience in implementing USAID, CDC and Bill and Melinda Gates Foundation–funded HIV and Reproductive Maternal Child Adolescent Health programs. He is currently the Chief of Party for a USAID-funded Health Leadership and Governance Project at Amref Health Africa. Previously, he served in various senior capacities including the Imarisha Jamii Project, the Fahari ya Jamii Project, and CDC ICAP at Columbia University Kenya. He holds a Bachelor’s degree in Medicine, a Master of Science in Health Systems Management and Policy, a Masters in Business Administration, and Masters in Obstetrics & Gynecology.' },
    bonventure: { name: 'Dr. Bonventure Machuka', role: 'Board Member', img: 'assets/img/team/bonventure.jpg', text: 'Bonventure Machuka is a medical doctor from Moi University, Kenya, and a global health researcher, policy advocate and youth leader. He serves as a Youth Ambassador with the Africa Health Collaborative and has worked with the AMPATH Consortium on research in equitable collaborations, critical care, climate and health, and medical education. A former Vice President of the Federation of African Medical Students’ Associations, he has contributed to WHO work on African medical education and climate-resilient health systems.' },
    noel: { name: 'Noel Murunga', role: 'Board Member', img: 'assets/img/team/noel.jpg', text: 'Noel Museshi is a bubbly civic leader passionate about Global Health advocacy, with a keen focus on adolescent and youth sexual and reproductive health. A graduate in Public Health from Kenyatta University and a UN Academic Impact Millennium Fellow, she is propelled into action by a commitment to servant leadership. She is a Program Coordinator at Reproductive and Sexual Health Programme for Kenyan Teenagers (RESPEKT) where she designs sexual and reproductive health training materials and strengthens capacity building and advocacy activities for adolescents within the country.' },
    nelly: { name: 'Dr. Nelly Bosire', role: 'CEO', img: 'assets/img/team/nelly.jpg', text: 'Dr. Nelly Bosire, MBChB, MMED (Obs/Gyn), is the Founder of Thriving Teens Foundation. She is a practising obstetrician & gynaecologist, a doctor for over 17 years, with a passion for adolescent health. She is an expert in Health Governance, Policy and Advocacy. She has worked as a Technical Consultant in legal and policy framework for SRHR, for various local and multinational organisations. Currently, she is a Technical Outcome Lead for KEPRECON. She takes a keen interest in the transition of children with chronic medical conditions from childhood, through adolescence, to adulthood with regard to reproductive health. She is also a health columnist.' },
    advisory: { name: 'Technical Advisory', role: 'Advisory / staff to the Executive Director', img: 'assets/img/team/dan.jpg', text: 'Specialists in obstetrics, paediatrics, cardiology, public health and quality improvement who keep our work evidence-based. Tap an advisor’s name to read their bio.' },
    dan: { name: 'Dr. Dan Odallo', role: 'Technical Advisor', img: 'assets/img/team/dan.jpg', text: 'Dr. Dan O. Odallo, MPH, PhD, is a Senior Program Advisor with Kenya Paediatrics Research Consortium (Keprecon), with specialisations in Program Management, Advocacy and Social Science Research. He is trained in Demography, Public Health (epidemiology) and Peace and Conflict Studies. Dr. Odallo worked as a Senior Population officer in the Government of Kenya, the Country Representative of the Johns Hopkins University (JHU/PCS), and as a UNAIDS program officer in South Africa.' },
    conrad: { name: 'Dr. Conrad Wanyama', role: 'Technical Advisor', img: 'assets/img/team/conrad.jpg', text: 'Dr. Conrad Wanyama is a public health specialist and researcher, currently working as a Research Officer with the KEMRI-Wellcome-Trust Research Programme, Kenya. He has worked as a clinical consultant in the LIFE (Life-saving Instruction for Emergencies) project. Previously, he has also worked as a clinical and emergencies instructor for Gertrudes Garden Children’s Hospital. He currently serves as a technical working group member for the Ministry of Health’s development of the Adolescent Health Policy.' },
    job: { name: 'Dr. Job Makoyo', role: 'Technical Advisor', img: 'assets/img/team/job.jpg', text: 'Dr. Job Makoyo is a public health specialist with an MBA in Healthcare Management. He is also a Sexual and Reproductive Health and Rights Expert and has a special interest in Quality Improvement. He currently serves as the Deputy Country Director for Jacaranda Health. Previously, he served as the Director, Programmes and Operations at Marie Stopes Kenya; Technical Lead, Quality of Care, WISH2ACTION, IPPF; and Senior Manager, Quality Assurance and Service Delivery at PSI.' },
    yubrine: { name: 'Dr. Yubrine Moraa Gachemba', role: 'Technical Advisor', img: 'assets/img/team/yubrine.jpg', text: 'Dr. Yubrine Moraa Gachemba is a subspecialist in training, currently pursuing her fellowship in cardio-obstetrics and cardiac imaging. She holds a postgraduate diploma in cardiology and is a specialist physician. She is very passionate about cardiac medicine throughout the entire spectrum of health.' },
    comms: { name: 'Communications', role: 'Advisory / staff to the Executive Director', img: 'assets/img/team/nelvin.jpg', text: 'Brand, youth voice and digital outreach. Tap a name to read their bio.' },
    laura: { name: 'Laura Dindi', role: 'Programme Manager', img: 'assets/img/team/laura.jpg', text: 'Laura Dindi is a Certified Nursing Assistant and health advocate focused on adolescent and young people’s health, reproductive health, health education and community wellbeing. Through Thriving Teens Foundation she supports health awareness, mentorship, advocacy and youth engagement, so young people have the knowledge and support to make informed decisions about their health.' },
    nelvin: { name: 'Nelvin Agwata', role: 'Communications Officer', img: 'assets/img/team/nelvin.jpg', text: 'Ms. Nelvin Agwata, BSc, believes in the power of technology, leveraging various products to equip adolescents with knowledge regarding their health. She works with children as the Chief Operations Officer, Petu Pazuri, a childcare and after-school programme service provider in Nairobi.' },
    lydia: { name: 'Lydia Mueni Muli', role: 'Programme Manager', img: 'assets/img/team/lydia.jpg', text: 'Lydia Mueni Muli is a health and development professional working at the intersection of people, public health and the environments they live in. Her experience spans health promotion, disease prevention, WASH, community and adolescent health, research, project management and health systems. She focuses on the social and environmental factors that shape wellbeing, and on turning that into effective programmes.' },
    wamuyu: { name: 'Wamuyu Mwangi', role: 'Project Manager', img: 'assets/img/team/wamuyu.jpg', text: 'Ms. Wamuyu Mwangi is committed to advocating for sexual and reproductive health and rights of all persons, especially adolescents and young adults. She is a computer science expert, an experienced peer educator and social media adviser.' },
    wangeci: { name: 'Dr. Wangeci Mbuthia', role: 'Technical Advisor', img: 'assets/img/team/wangeci.jpg', text: 'Dr. Wangeci Mbuthia, MBChB, MMED (Obs/Gyn), is a practising obstetrician and gynaecologist, a doctor for the past 16 years, with special interest in adolescents with HIV and AIDS. She serves as the course director for the Advanced Life Support in Obstetrics (ALSO) training in the Institute of Family Medicine (INFA-MED), Kenyan chapter. She has a keen interest in continuous medical training and research that informs and updates healthcare professionals especially in resource poor settings on evidence-based local solutions with the aim of reducing maternal and infant morbidity and mortality.' },
    wanjiru: { name: 'Wanjiru Mwangi', role: 'Head of Programmes', img: 'assets/img/team/wanjiru.jpg', text: 'Wanjiru Mwangi is a purpose-driven project management and youth development professional. Her work spans programme coordination, MEL, youth engagement, adolescent SRHR and stakeholder engagement. She takes a people-centred, evidence-informed approach so young people can shape the programmes and decisions that affect their lives.' },
    joyce: { name: 'Joyce Imusarit', role: 'Project Officer', img: 'assets/img/team/joyce.jpg', text: 'Ms. Joyce Imusarit is a passionate advocate for adolescent moms, with a focus on the “Return to School” policy. From her own experience, she believes that every adolescent mom, given a chance, can excel in life, through the power of education.' },
    mercy: { name: 'Mercy Weru', role: 'Head of Operations', img: 'assets/img/team/mercy.jpg', text: 'Mercy Wangu is a passionate youth development advocate and administrator dedicated to empowering and supporting young people. She serves in an administrative role within a teen-focused organization, coordinating programs and activities that create positive impact. With additional expertise in logistics, project coordination, and civil engineering, she brings strong organization, leadership, and problem-solving skills to her work.' },
    proc: { name: 'Procurement', role: 'Reports to Director – Operations', img: 'assets/img/team/vacant-proc.jpg', text: 'This seat is open. Procurement will sit under Operations when the role is filled.' },
    hr: { name: 'HR', role: 'Reports to Director – Operations', img: 'assets/img/team/vacant-hr.jpg', text: 'This seat is open. Human resources will sit under Operations when the role is filled.' },
    fin: { name: 'Finance', role: 'Reports to Director – Operations', img: 'assets/img/team/vacant-fin.jpg', text: 'Finance leads fiscal management under Operations. This seat is shown on the chart until a named lead is appointed.' },
    audit: { name: 'Audit', role: 'Reports to Director – Operations', img: 'assets/img/team/vacant-audit.jpg', text: 'Audit provides assurance, risk and compliance oversight under Operations. This seat is shown on the chart until a named lead is appointed.' },
    ops: { name: 'Head of Operations', role: 'Administrative leadership', img: '', text: 'Head of Operations provides administrative leadership. Direct reports: Procurement, Admin + HR, and Finance.' },
    pm: { name: 'Programme Managers', role: 'Field execution & grants · reports to Head of Programmes', img: '', text: 'Programme Managers handle field execution and grants under the Head of Programmes.' },
    hr: { name: 'HR', role: 'Reports to Director – Operations', img: 'assets/img/team/vacant-hr.jpg', text: 'Admin + HR covers people, personal support and facilities under Operations.' }
  };
  var orgBio = $('#orgBio');
  var orgScrim = $('#orgBioScrim');
  function hideOrgBio() {
    if (orgBio) orgBio.hidden = true;
    if (orgScrim) orgScrim.hidden = true;
    document.body.style.overflow = '';
  }
  function showOrgBio(id) {
    var d = ORG_BIOS[id];
    if (!d || !orgBio) return;
    $('#orgBioName').textContent = d.name;
    $('#orgBioRole').textContent = d.role;
    $('#orgBioText').textContent = d.text;
    var img = $('#orgBioImg');
    if (d.img) { img.hidden = false; img.src = ROOT + d.img; img.alt = d.name; }
    else { img.hidden = true; img.removeAttribute('src'); }
    orgBio.hidden = false;
    if (orgScrim) orgScrim.hidden = false;
    document.body.style.overflow = 'hidden';
    $$('[data-bio]').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-bio') === id); });
  }
  $$('[data-bio]').forEach(function (b) {
    b.addEventListener('click', function (e) { e.stopPropagation(); showOrgBio(b.getAttribute('data-bio')); });
    b.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); showOrgBio(b.getAttribute('data-bio')); }
    });
  });
  var orgClose = $('.org-bio-close');
  if (orgClose) orgClose.addEventListener('click', hideOrgBio);
  if (orgScrim) orgScrim.addEventListener('click', hideOrgBio);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hideOrgBio(); });

  /* ---------- Quick exit (safeguarding) ---------- */
  $$('.quick-exit').forEach(function (b) {
    b.addEventListener('click', function () { window.open('https://www.google.com/search?q=weather+nairobi', '_self'); window.location.replace('https://www.google.com/search?q=weather+nairobi'); });
  });

  /* ---------- Share / copy link ---------- */
  $$('[data-copy-link]').forEach(function (b) {
    b.addEventListener('click', function () {
      var url = window.location.href;
      if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { toast('Link copied to clipboard'); });
      else toast(url);
    });
  });
})();
